import { jsxLocPlugin } from "@builder.io/vite-plugin-jsx-loc";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import fs from "node:fs";
import path from "node:path";
import { defineConfig, type Plugin, type ViteDevServer } from "vite";
import { vitePluginManusRuntime } from "vite-plugin-manus-runtime";

// =============================================================================
// Manus Debug Collector - Vite Plugin
// Writes browser logs directly to files, trimmed when exceeding size limit
// =============================================================================

const PROJECT_ROOT = import.meta.dirname;
const LOG_DIR = path.join(PROJECT_ROOT, ".manus-logs");
const MAX_LOG_SIZE_BYTES = 1 * 1024 * 1024; // 1MB per log file
const TRIM_TARGET_BYTES = Math.floor(MAX_LOG_SIZE_BYTES * 0.6); // Trim to 60% to avoid constant re-trimming

type LogSource = "browserConsole" | "networkRequests" | "sessionReplay";

function ensureLogDir() {
  if (!fs.existsSync(LOG_DIR)) {
    fs.mkdirSync(LOG_DIR, { recursive: true });
  }
}

function trimLogFile(logPath: string, maxSize: number) {
  try {
    if (!fs.existsSync(logPath) || fs.statSync(logPath).size <= maxSize) {
      return;
    }

    const lines = fs.readFileSync(logPath, "utf-8").split("\n");
    const keptLines: string[] = [];
    let keptBytes = 0;

    // Keep newest lines (from end) that fit within 60% of maxSize
    const targetSize = TRIM_TARGET_BYTES;
    for (let i = lines.length - 1; i >= 0; i--) {
      const lineBytes = Buffer.byteLength(`${lines[i]}\n`, "utf-8");
      if (keptBytes + lineBytes > targetSize) break;
      keptLines.unshift(lines[i]);
      keptBytes += lineBytes;
    }

    fs.writeFileSync(logPath, keptLines.join("\n"), "utf-8");
  } catch {
    /* ignore trim errors */
  }
}

function writeToLogFile(source: LogSource, entries: unknown[]) {
  if (entries.length === 0) return;

  ensureLogDir();
  const logPath = path.join(LOG_DIR, `${source}.log`);

  // Format entries with timestamps
  const lines = entries.map((entry) => {
    const ts = new Date().toISOString();
    return `[${ts}] ${JSON.stringify(entry)}`;
  });

  // Append to log file
  fs.appendFileSync(logPath, `${lines.join("\n")}\n`, "utf-8");

  // Trim if exceeds max size
  trimLogFile(logPath, MAX_LOG_SIZE_BYTES);
}

/**
 * Vite plugin to collect browser debug logs
 * - POST /__manus__/logs: Browser sends logs, written directly to files
 * - Files: browserConsole.log, networkRequests.log, sessionReplay.log
 * - Auto-trimmed when exceeding 1MB (keeps newest entries)
 */
function vitePluginManusDebugCollector(): Plugin {
  return {
    name: "manus-debug-collector",

    transformIndexHtml(html) {
      if (process.env.NODE_ENV === "production") {
        return html;
      }
      return {
        html,
        tags: [
          {
            tag: "script",
            attrs: {
              src: "/__manus__/debug-collector.js",
              defer: true,
            },
            injectTo: "head",
          },
        ],
      };
    },

    configureServer(server: ViteDevServer) {
      // POST /__manus__/logs: Browser sends logs (written directly to files)
      server.middlewares.use("/__manus__/logs", (req, res, next) => {
        if (req.method !== "POST") {
          return next();
        }

        const handlePayload = (payload: any) => {
          // Write logs directly to files
          if (payload.consoleLogs?.length > 0) {
            writeToLogFile("browserConsole", payload.consoleLogs);
          }
          if (payload.networkRequests?.length > 0) {
            writeToLogFile("networkRequests", payload.networkRequests);
          }
          if (payload.sessionEvents?.length > 0) {
            writeToLogFile("sessionReplay", payload.sessionEvents);
          }

          res.writeHead(200, { "Content-Type": "application/json" });
          res.end(JSON.stringify({ success: true }));
        };

        const reqBody = (req as { body?: unknown }).body;
        if (reqBody && typeof reqBody === "object") {
          try {
            handlePayload(reqBody);
          } catch (e) {
            res.writeHead(400, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ success: false, error: String(e) }));
          }
          return;
        }

        let body = "";
        req.on("data", (chunk) => {
          body += chunk.toString();
        });

        req.on("end", () => {
          try {
            const payload = JSON.parse(body);
            handlePayload(payload);
          } catch (e) {
            res.writeHead(400, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ success: false, error: String(e) }));
          }
        });
      });
    },
  };
}

function vitePluginStorageProxy(): Plugin {
  return {
    name: "manus-storage-proxy",
    configureServer(server: ViteDevServer) {
      server.middlewares.use("/manus-storage", async (req, res) => {
        const key = req.url?.replace(/^\//, "");
        if (!key) {
          res.writeHead(400, { "Content-Type": "text/plain" });
          res.end("Missing storage key");
          return;
        }

        const forgeBaseUrl = (process.env.BUILT_IN_FORGE_API_URL || "").replace(/\/+$/, "");
        const forgeKey = process.env.BUILT_IN_FORGE_API_KEY;

        if (!forgeBaseUrl || !forgeKey) {
          res.writeHead(500, { "Content-Type": "text/plain" });
          res.end("Storage proxy not configured");
          return;
        }

        try {
          const forgeUrl = new URL("v1/storage/presign/get", forgeBaseUrl + "/");
          forgeUrl.searchParams.set("path", key);

          const forgeResp = await fetch(forgeUrl, {
            headers: { Authorization: `Bearer ${forgeKey}` },
          });

          if (!forgeResp.ok) {
            res.writeHead(502, { "Content-Type": "text/plain" });
            res.end("Storage backend error");
            return;
          }

          const { url } = (await forgeResp.json()) as { url: string };
          if (!url) {
            res.writeHead(502, { "Content-Type": "text/plain" });
            res.end("Empty signed URL");
            return;
          }

          res.writeHead(307, { Location: url, "Cache-Control": "no-store" });
          res.end();
        } catch {
          res.writeHead(502, { "Content-Type": "text/plain" });
          res.end("Storage proxy error");
        }
      });
    },
  };
}

function vitePluginTrafficProxy(): Plugin {
  return {
    name: "tomtom-traffic-proxy",
    configureServer(server: ViteDevServer) {
      server.middlewares.use("/api/assistant", async (req, res) => {
        if (req.method !== "POST") return;
        let body = "";
        req.on("data", (chunk) => { body += chunk.toString(); });
        req.on("end", async () => {
          try {
            const payload = JSON.parse(body) as { question?: string; context?: string };
            const question = typeof payload.question === "string" ? payload.question.trim() : "";
            const context = typeof payload.context === "string" ? payload.context.slice(0, 6000) : "";
            const forgeBaseUrl = (process.env.BUILT_IN_FORGE_API_URL || "").replace(/\/+$/, "");
            const forgeKey = process.env.BUILT_IN_FORGE_API_KEY;
            if (!question) { res.writeHead(400, { "Content-Type": "application/json" }); res.end(JSON.stringify({ error: "A question is required" })); return; }
            if (!forgeBaseUrl || !forgeKey) { res.writeHead(503, { "Content-Type": "application/json" }); res.end(JSON.stringify({ error: "AI assistant is not configured" })); return; }
            const system = `You are ResQ-Pulse AI, the helpful operational guide for the ResQ-Pulse disaster resource allocation and commuter safety dashboard. Answer clearly and briefly in plain language. You know the website's features and data sources. Never claim a live value unless it appears in the supplied context. Explain that weather and forecasts come from Open-Meteo; city search comes from Nominatim; maps use OpenStreetMap; live traffic flow and traffic tiles come from TomTom; alert-source labels include IMD, NDMA SACHET, CWC, CPCB, NHAI, state transport/police, and TrackChild. Be transparent that predicted vehicle counts are estimates based on city baseline, local time, weather, and TomTom congestion, not camera counts. Do not invent official alerts, emergency instructions, contacts, or source data. For urgent real-world emergencies, direct the user to local emergency services and official authorities. Current dashboard context:\n${context}`;
            const response = await fetch(`${forgeBaseUrl}/v1/chat/completions`, { method: "POST", headers: { Authorization: `Bearer ${forgeKey}`, "Content-Type": "application/json" }, body: JSON.stringify({ model: "gpt-5-mini", messages: [{ role: "system", content: system }, { role: "user", content: question }], max_completion_tokens: 500 }) });
            const result = await response.json() as { choices?: Array<{ message?: { content?: string } }>; error?: { message?: string } };
            res.writeHead(response.ok ? 200 : 502, { "Content-Type": "application/json" });
            res.end(JSON.stringify(response.ok ? { answer: result.choices?.[0]?.message?.content || "I could not generate an answer right now." } : { error: result.error?.message || "AI assistant request failed" }));
          } catch (error) { res.writeHead(502, { "Content-Type": "application/json" }); res.end(JSON.stringify({ error: error instanceof Error ? error.message : "AI assistant request failed" })); }
        });
      });
      server.middlewares.use("/api/geocode", async (req, res) => {
        if (req.method !== "GET") return;
        const requestUrl = new URL(req.url || "/", "http://localhost");
        const query = requestUrl.searchParams.get("q")?.trim() || "";
        if (!query) { res.writeHead(400, { "Content-Type": "application/json" }); res.end(JSON.stringify({ error: "A search query is required" })); return; }
        try {
          const params = new URLSearchParams({ q: query, format: "jsonv2", addressdetails: "1", limit: "7" });
          const response = await fetch(`https://nominatim.openstreetmap.org/search?${params.toString()}`, { headers: { "User-Agent": "ResQ-Pulse/1.0 (live emergency operations dashboard)", "Accept-Language": "en" } });
          const body = await response.text();
          res.writeHead(response.status, { "Content-Type": "application/json" });
          res.end(body);
        } catch (error) {
          res.writeHead(502, { "Content-Type": "application/json" });
          res.end(JSON.stringify({ error: error instanceof Error ? error.message : "Nominatim search failed" }));
        }
      });

      server.middlewares.use("/api/traffic-flow", async (req, res) => {
        if (req.method !== "GET") return;
        const requestUrl = new URL(req.url || "/", "http://localhost");
        const latitude = Number(requestUrl.searchParams.get("latitude"));
        const longitude = Number(requestUrl.searchParams.get("longitude"));
        const apiKey = process.env.TOMTOM_API_KEY;
        if (!apiKey) { res.writeHead(503, { "Content-Type": "application/json" }); res.end(JSON.stringify({ error: "TOMTOM_API_KEY is not configured" })); return; }
        if (!Number.isFinite(latitude) || !Number.isFinite(longitude) || latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180) { res.writeHead(400, { "Content-Type": "application/json" }); res.end(JSON.stringify({ error: "Valid latitude and longitude are required" })); return; }
        const params = new URLSearchParams({ point: `${latitude},${longitude}`, unit: "KMPH", key: apiKey });
        try {
          const response = await fetch(`https://api.tomtom.com/traffic/services/4/flowSegmentData/absolute/10/json?${params.toString()}`);
          const body = await response.text();
          res.writeHead(response.status, { "Content-Type": "application/json" });
          res.end(body);
        } catch (error) {
          res.writeHead(502, { "Content-Type": "application/json" });
          res.end(JSON.stringify({ error: error instanceof Error ? error.message : "TomTom traffic request failed" }));
        }
      });

      server.middlewares.use("/api/tomtom-tile", async (req, res) => {
        if (req.method !== "GET") return;
        const pathParts = (req.url || "").split("?")[0].split("/").filter(Boolean);
        const [z, x, y] = pathParts;
        const apiKey = process.env.TOMTOM_API_KEY;
        if (!apiKey) { res.writeHead(503, { "Content-Type": "text/plain" }); res.end("TOMTOM_API_KEY is not configured"); return; }
        if (![z, x, y].every((value) => /^\d+$/.test(value || ""))) { res.writeHead(400, { "Content-Type": "text/plain" }); res.end("Invalid tile coordinates"); return; }
        try {
          const response = await fetch(`https://api.tomtom.com/traffic/map/4/tile/flow/relative/${z}/${x}/${y}.png?key=${encodeURIComponent(apiKey)}`);
          if (!response.ok) { res.writeHead(response.status, { "Content-Type": "text/plain" }); res.end(await response.text()); return; }
          res.writeHead(200, { "Content-Type": response.headers.get("content-type") || "image/png", "Cache-Control": "public, max-age=30" });
          res.end(Buffer.from(await response.arrayBuffer()));
        } catch (error) {
          res.writeHead(502, { "Content-Type": "text/plain" });
          res.end(error instanceof Error ? error.message : "TomTom traffic tile request failed");
        }
      });
    },
  };
}

const plugins = [react(), tailwindcss(), jsxLocPlugin(), vitePluginManusRuntime(), vitePluginManusDebugCollector(), vitePluginStorageProxy(), vitePluginTrafficProxy()];

export default defineConfig({
  plugins,
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets"),
    },
  },
  envDir: path.resolve(import.meta.dirname),
  root: path.resolve(import.meta.dirname, "client"),
  publicDir: path.resolve(import.meta.dirname, "client", "public"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true,
  },
  server: {
    host: true,
    allowedHosts: [
      ".manuspre.computer",
      ".manus.computer",
      ".manus-asia.computer",
      ".manuscomputer.ai",
      ".manusvm.computer",
      "localhost",
      "127.0.0.1",
    ],
    fs: {
      strict: true,
      deny: ["**/.*"],
    },
  },
});
