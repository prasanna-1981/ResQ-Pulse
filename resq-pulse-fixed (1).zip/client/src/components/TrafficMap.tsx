import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

type TrafficMapProps = {
  latitude: number;
  longitude: number;
  locationName: string;
};

export default function TrafficMap({ latitude, longitude, locationName }: TrafficMapProps) {
  const mapElement = useRef<HTMLDivElement | null>(null);
  const mapInstance = useRef<L.Map | null>(null);
  const markerInstance = useRef<L.Marker | null>(null);

  useEffect(() => {
    if (!mapElement.current || mapInstance.current) return;
    const map = L.map(mapElement.current, { zoomControl: false }).setView([latitude, longitude], 11);
    L.control.zoom({ position: "bottomright" }).addTo(map);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "© OpenStreetMap contributors",
      maxZoom: 19,
    }).addTo(map);
    L.tileLayer("/api/tomtom-tile/{z}/{x}/{y}?style=relative", {
      attribution: "Traffic © TomTom",
      opacity: 0.92,
      maxZoom: 18,
    }).addTo(map);
    markerInstance.current = L.marker([latitude, longitude]).addTo(map).bindTooltip(locationName, { direction: "top", offset: [0, -8] }).openTooltip();
    mapInstance.current = map;

    return () => {
      map.remove();
      mapInstance.current = null;
      markerInstance.current = null;
    };
  }, []);

  useEffect(() => {
    const map = mapInstance.current;
    if (!map) return;
    map.setView([latitude, longitude], 11, { animate: true });
    markerInstance.current?.setLatLng([latitude, longitude]).setTooltipContent(locationName).openTooltip();
    window.setTimeout(() => map.invalidateSize(), 120);
  }, [latitude, longitude, locationName]);

  return <div className="traffic-map-canvas"><div className="traffic-map" ref={mapElement} aria-label={`OpenStreetMap with TomTom live traffic flow centered on ${locationName}`} /><div className="traffic-legend" aria-label="Traffic color legend"><span className="traffic-legend-title">LIVE FLOW</span><span><i className="green" /> Free movement</span><span><i className="orange" /> Medium traffic</span><span><i className="red" /> High traffic</span></div></div>;
}
