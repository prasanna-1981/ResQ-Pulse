import { describe, expect, it } from "vitest";

describe("TomTom traffic credentials", () => {
  it("authorizes a lightweight traffic flow request", async () => {
    const key = process.env.TOMTOM_API_KEY;
    expect(key, "TOMTOM_API_KEY must be configured").toBeTruthy();

    const params = new URLSearchParams({
      point: "17.385,78.4867",
      unit: "KMPH",
      key: key || "",
    });
    const response = await fetch(`https://api.tomtom.com/traffic/services/4/flowSegmentData/absolute/10/json?${params.toString()}`);
    const body = await response.text();
    expect(response.ok, body).toBe(true);

    const payload = JSON.parse(body) as { flowSegmentData?: { currentSpeed?: number } };
    expect(payload.flowSegmentData).toBeDefined();
    expect(typeof payload.flowSegmentData?.currentSpeed).toBe("number");
  }, 15_000);
});
