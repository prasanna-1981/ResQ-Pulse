import { Fragment, FormEvent, useEffect, useMemo, useState } from "react";
import {
  Activity,
  AlertTriangle,
  ArrowDownRight,
  ArrowUpRight,
  Bike,
  Bot,
  Boxes,
  CarFront,
  Check,
  ChevronRight,
  CircleAlert,
  Clock3,
  CloudRain,
  Crosshair,
  Droplets,
  Gauge,
  Globe2,
  HeartPulse,
  LocateFixed,
  MapPin,
  MessageCircle,
  Navigation,
  PackageCheck,
  Pin,
  Radio,
  RefreshCw,
  Route,
  Search,
  Send,
  ShieldAlert,
  Siren,
  Thermometer,
  Truck,
  Warehouse,
  Waves,
  Wind,
  X,
  Zap,
} from "lucide-react";
import TrafficMap from "@/components/TrafficMap";

type LocationResult = {
  id?: number;
  name: string;
  country?: string;
  country_code?: string;
  admin1?: string;
  latitude: number;
  longitude: number;
  timezone?: string;
  display_name?: string;
};

type TrafficFlowResponse = {
  flowSegmentData?: {
    currentSpeed?: number;
    freeFlowSpeed?: number;
    currentTravelTime?: number;
    freeFlowTravelTime?: number;
    confidence?: number;
    roadClosure?: boolean;
    frc?: string;
  };
};

type WeatherResponse = {
  latitude: number;
  longitude: number;
  timezone: string;
  current: {
    time: string;
    temperature_2m: number;
    apparent_temperature: number;
    relative_humidity_2m: number;
    precipitation: number;
    wind_speed_10m: number;
    uv_index: number;
    weather_code: number;
  };
  current_units: {
    temperature_2m: string;
    relative_humidity_2m: string;
    precipitation: string;
    wind_speed_10m: string;
  };
  daily: {
    time: string[];
    weather_code: number[];
    temperature_2m_max: number[];
    uv_index_max: number[];
    precipitation_sum: number[];
    precipitation_probability_max: number[];
    wind_speed_10m_max: number[];
  };
};

type FleetMode = "bike" | "car" | "fleet";
type Threat = "severe" | "watch" | "stable";
type DispatchPlan = {
  route: string;
  eta: number;
  leadResource: string;
  quantity: number;
  createdAt: Date;
};
type CapacityProfile = Record<string, { stock: number; baseNeed: number }>;
type CapacityDraft = Record<string, { stock: string; baseNeed: string }>;
type AlertCategory = "Weather" | "Road" | "Fire" | "Flood" | "Air Quality" | "Civic";
type SmartAlert = { id: string; category: AlertCategory; icon: string; severity: "HIGH" | "WATCH" | "ADVISORY"; type: string; location: string; time: string; issuer: string; headline: string; detail: string; supply: string; relief: string; actions: string[]; verified: boolean };
type MissingPersonReport = { id: string; name: string; age: string; lastSeen: string; contact: string; notes: string; location: string; reportedAt: string };

const QUICK_CITIES: LocationResult[] = [
  { name: "Hyderabad", country: "India", country_code: "IN", latitude: 17.385, longitude: 78.4867, timezone: "Asia/Kolkata" },
  { name: "Mumbai", country: "India", country_code: "IN", latitude: 19.076, longitude: 72.8777, timezone: "Asia/Kolkata" },
  { name: "Chennai", country: "India", country_code: "IN", latitude: 13.0827, longitude: 80.2707, timezone: "Asia/Kolkata" },
  { name: "Guwahati", country: "India", country_code: "IN", latitude: 26.1445, longitude: 91.7362, timezone: "Asia/Kolkata" },
  { name: "Tokyo", country: "Japan", country_code: "JP", latitude: 35.6762, longitude: 139.6503, timezone: "Asia/Tokyo" },
  { name: "London", country: "United Kingdom", country_code: "GB", latitude: 51.5072, longitude: -0.1276, timezone: "Europe/London" },
];

const weatherCodeLabel = (code: number) => {
  if (code === 0) return "Clear sky";
  if ([1, 2, 3].includes(code)) return "Partly cloudy";
  if ([45, 48].includes(code)) return "Fog / low visibility";
  if ([51, 53, 55, 56, 57].includes(code)) return "Drizzle";
  if ([61, 63, 65, 66, 67].includes(code)) return "Rain";
  if ([71, 73, 75, 77].includes(code)) return "Snow";
  if ([80, 81, 82].includes(code)) return "Rain showers";
  if ([95, 96, 99].includes(code)) return "Thunderstorm";
  return "Variable conditions";
};

const formatDate = (date: string, options: Intl.DateTimeFormatOptions = { weekday: "short", month: "short", day: "numeric" }) =>
  new Intl.DateTimeFormat("en-US", options).format(new Date(`${date}T12:00:00`));

const formatTime = (date: string, timezone?: string) =>
  new Intl.DateTimeFormat("en-US", { hour: "2-digit", minute: "2-digit", timeZone: timezone || undefined }).format(new Date(date));

const formatTimezoneLabel = (timezone?: string) => {
  if (!timezone) return "Local time";
  const city = timezone.split("/").pop()?.replaceAll("_", " ") || timezone;
  const shortZone = new Intl.DateTimeFormat("en-US", { timeZone: timezone, timeZoneName: "short" }).formatToParts(new Date()).find((part) => part.type === "timeZoneName")?.value;
  return `${city} · ${shortZone || "local"}`;
};

const getThreat = (rain: number, wind: number): Threat => {
  if (rain > 5 || wind > 35) return "severe";
  if (rain > 1 || wind > 25) return "watch";
  return "stable";
};

const threatMeta: Record<Threat, { label: string; color: string; detail: string }> = {
  severe: { label: "SEVERE", color: "red", detail: "Active disruption probability elevated" },
  watch: { label: "WATCH", color: "amber", detail: "Monitor conditions and stage flex capacity" },
  stable: { label: "STABLE", color: "cyan", detail: "Baseline operating conditions" },
};

const resourceSeed = [
  { name: "Medical trauma kits", short: "Trauma kits", stock: 250, baseNeed: 700, unit: "kits", icon: HeartPulse, color: "rose" },
  { name: "Potable drinking water", short: "Potable water", stock: 6000, baseNeed: 20000, unit: "L", icon: Droplets, color: "cyan" },
  { name: "Rescue boats / convoys", short: "Boats / convoys", stock: 10, baseNeed: 28, unit: "units", icon: Truck, color: "amber" },
  { name: "Temporary emergency shelters", short: "Emergency shelters", stock: 200, baseNeed: 200, unit: "units", icon: Warehouse, color: "violet" },
];

const createCapacityProfile = (stockFactor: number, needFactor: number): CapacityProfile => Object.fromEntries(resourceSeed.map((resource) => [resource.name, { stock: Math.round(resource.stock * stockFactor), baseNeed: Math.round(resource.baseNeed * needFactor) }])) as CapacityProfile;
const DEFAULT_CAPACITY_BY_CITY: Record<string, CapacityProfile> = {
  Hyderabad: createCapacityProfile(1, 1),
  Mumbai: createCapacityProfile(0.82, 1.2),
  Chennai: createCapacityProfile(0.9, 1.12),
  Guwahati: createCapacityProfile(0.62, 1.3),
  Tokyo: createCapacityProfile(1.55, 0.82),
  London: createCapacityProfile(1.25, 0.76),
};

const TRAFFIC_BASELINE_BY_CITY: Record<string, { total: number; bikeShare: number; carShare: number; heavyShare: number; jamAt: number }> = {
  Hyderabad: { total: 12800, bikeShare: 0.52, carShare: 0.39, heavyShare: 0.09, jamAt: 17000 },
  Mumbai: { total: 18600, bikeShare: 0.38, carShare: 0.51, heavyShare: 0.11, jamAt: 22000 },
  Chennai: { total: 11200, bikeShare: 0.45, carShare: 0.44, heavyShare: 0.11, jamAt: 16500 },
  Guwahati: { total: 5400, bikeShare: 0.56, carShare: 0.34, heavyShare: 0.10, jamAt: 8200 },
  Tokyo: { total: 24000, bikeShare: 0.18, carShare: 0.63, heavyShare: 0.19, jamAt: 30000 },
  London: { total: 16500, bikeShare: 0.10, carShare: 0.71, heavyShare: 0.19, jamAt: 21500 },
};

const SMART_ALERTS: SmartAlert[] = [
  { id: "cyclone", category: "Weather", icon: "🌩️", severity: "HIGH", type: "Cyclone Warning", location: "Coastal Andhra Pradesh · 2.3 km from Supplier D plant", time: "14:20", issuer: "India Meteorological Department (IMD)", headline: "Severe cyclone expected to make landfall Wed midnight", detail: "Landfall expected in 36h · wind forecast 92 km/h · affected districts: Nalgonda and coastal AP.", supply: "Port of Krishnapatnam inbound: 2 shipments may face a 4–7 day delay.", relief: "4 relief camps in flood-prone districts; pre-position 200 units of drinking water.", actions: ["View affected components", "Pin to decisions", "Dismiss"], verified: true },
  { id: "road-closure", category: "Road", icon: "🚗", severity: "WATCH", type: "Road Closure", location: "NH-44, Kurnool district · 42 km from primary route", time: "13:55", issuer: "NHAI Road Operations", headline: "Heavy vehicle accident blocking northbound lane", detail: "Overturned container · estimated clearance 5h · alternate NH-48 route available.", supply: "Consignment #4471 reroute adds 6h; no production impact with buffer stock.", relief: "Drinking-water dispatch to Zone C delayed; alternate route adds 22 minutes.", actions: ["Track incident", "Pin to decisions", "Dismiss"], verified: true },
  { id: "flood", category: "Flood", icon: "🌊", severity: "HIGH", type: "Flood Warning", location: "Hyderabad · Musi River corridor · 3.2 km from NH-65 access", time: "12:45", issuer: "Central Water Commission", headline: "Musi river above danger level — 72-hour peak forecast", detail: "Current level 45.2m vs danger 44.8m · forecast peak 46.8m Thursday 14:00.", supply: "4 inbound components may see 2–3 day shipping delays; buffer stock window is 24h.", relief: "3 low-lying camps · 600 people; secondary access via Outer Ring Road.", actions: ["Update relief plan", "Pin to decisions", "Dismiss"], verified: true },
  { id: "fire", category: "Fire", icon: "🔥", severity: "WATCH", type: "Industrial Fire", location: "Ranipet SEZ, Tamil Nadu · 1.8 km from Tier-2 supplier", time: "13:00", issuer: "Tamil Nadu Fire Department", headline: "Large industrial fire near electronics cluster", detail: "70% contained, expanding 2% per hour; wind direction is being monitored.", supply: "Capacitor CAP-102 supplier at high risk; alternate supplier adds 5 days and 8% cost.", relief: "2 warehouses storing water and tarps are inside the 10 km monitoring zone.", actions: ["Monitor supplier status", "Pin to decisions", "Dismiss"], verified: true },
  { id: "aqi", category: "Air Quality", icon: "🏭", severity: "ADVISORY", type: "Air Quality Warning", location: "Delhi NCR · 800 km from Supplier D", time: "13:30", issuer: "Central Pollution Control Board (CPCB)", headline: "AQI 312 (Very Poor) — industrial restrictions likely", detail: "GRAP Stage III forecast in 18h; partial shutdown risk is 2–3 days.", supply: "Supplier D provides 12% of PCB sourcing; capacity may reduce by 40%.", relief: "Three camps need respiratory protection; PPE plan has 200 units for a 300-unit need.", actions: ["Activate contingency", "Pin to decisions", "Dismiss"], verified: true },
  { id: "strike", category: "Civic", icon: "🏫", severity: "WATCH", type: "Local Emergency Notice", location: "Telangana · primary commute and freight routes", time: "13:15", issuer: "Telangana Transport Department", headline: "State bus services suspended for 48 hours", detail: "Monday 06:00 through Tuesday 23:59 · private carrier availability estimated at 80%.", supply: "Inbound road freight may add 2–3h; private logistics rates up 15%.", relief: "Outbound relief dispatches need contingency vehicles; 180 staff commutes affected.", actions: ["Arrange private transport", "Pin to decisions", "Dismiss"], verified: true },
];

const compactNumber = (value: number) => new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 }).format(value);

const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));

export default function Home() {
  const [location, setLocation] = useState<LocationResult>(QUICK_CITIES[0]);
  const [weather, setWeather] = useState<WeatherResponse | null>(null);
  const [trafficFlow, setTrafficFlow] = useState<TrafficFlowResponse | null>(null);
  const [trafficLoading, setTrafficLoading] = useState(false);
  const [trafficError, setTrafficError] = useState("");
  const [search, setSearch] = useState("");
  const [searchResults, setSearchResults] = useState<LocationResult[]>([]);
  const [fleetMode, setFleetMode] = useState<FleetMode>("bike");
  const [isLoading, setIsLoading] = useState(true);
  const [isSearching, setIsSearching] = useState(false);
  const [error, setError] = useState("");
  const [lastSynced, setLastSynced] = useState(new Date());
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [dispatchPlan, setDispatchPlan] = useState<DispatchPlan | null>(null);
  const [activeSection, setActiveSection] = useState("command");
  const [opsMenuOpen, setOpsMenuOpen] = useState(false);
  const [dispatchLogOpen, setDispatchLogOpen] = useState(false);
  const [expandedRecommendation, setExpandedRecommendation] = useState<number | null>(null);
  const [acceptedRecommendations, setAcceptedRecommendations] = useState<number[]>([]);
  const [deferredRecommendations, setDeferredRecommendations] = useState<number[]>([]);
  const [expandedAlternative, setExpandedAlternative] = useState<string | null>(null);
  const [stagingAction, setStagingAction] = useState<"accepted" | "deferred" | null>(null);
  const [showDeferralImpact, setShowDeferralImpact] = useState(false);
  const [updatesPaused, setUpdatesPaused] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [alertFilter, setAlertFilter] = useState<"All" | AlertCategory>("All");
  const [dismissedAlerts, setDismissedAlerts] = useState<string[]>([]);
  const [pinnedAlert, setPinnedAlert] = useState<string | null>(null);
  const [expandedAlert, setExpandedAlert] = useState<string | null>(null);
  const [alertActionMessage, setAlertActionMessage] = useState("");
  const [assistantOpen, setAssistantOpen] = useState(false);
  const [assistantGreeting, setAssistantGreeting] = useState(true);
  const [assistantInput, setAssistantInput] = useState("");
  const [assistantLoading, setAssistantLoading] = useState(false);
  const [assistantMessages, setAssistantMessages] = useState<Array<{ role: "assistant" | "user"; text: string }>>([
    { role: "assistant", text: "Hi, I’m Pulse — your ResQ-Pulse guide. Ask me about the dashboard, live conditions, predictions, or the data sources behind them." },
  ]);
  const [isEditingCapacity, setIsEditingCapacity] = useState(false);
  const [capacityProfiles, setCapacityProfiles] = useState<Record<string, CapacityProfile>>(() => {
    try {
      const saved = window.localStorage.getItem("resq-pulse-capacity-profiles");
      return saved ? JSON.parse(saved) as Record<string, CapacityProfile> : DEFAULT_CAPACITY_BY_CITY;
    } catch {
      return DEFAULT_CAPACITY_BY_CITY;
    }
  });
  const [capacityDraft, setCapacityDraft] = useState<CapacityDraft>({});
  const [missingPeople, setMissingPeople] = useState<MissingPersonReport[]>(() => {
    try {
      const saved = window.localStorage.getItem("resq-pulse-missing-people");
      return saved ? JSON.parse(saved) as MissingPersonReport[] : [];
    } catch {
      return [];
    }
  });
  const [missingPersonDraft, setMissingPersonDraft] = useState({ name: "", age: "", lastSeen: "", contact: "", notes: "" });

  const activeCapacity = capacityProfiles[location.name] || DEFAULT_CAPACITY_BY_CITY[location.name] || createCapacityProfile(1, 1);
  const jumpTo = (section: string, targetId: string) => {
    setActiveSection(section);
    document.getElementById(targetId)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };
  const openCapacityEditor = () => {
    setCapacityDraft(Object.fromEntries(resourceSeed.map((resource) => {
      const value = activeCapacity[resource.name] || { stock: resource.stock, baseNeed: resource.baseNeed };
      return [resource.name, { stock: String(value.stock), baseNeed: String(value.baseNeed) }];
    })) as CapacityDraft);
    setIsEditingCapacity(true);
  };
  const updateCapacityDraft = (name: string, field: "stock" | "baseNeed", value: string) => {
    setCapacityDraft((draft) => ({ ...draft, [name]: { ...draft[name], [field]: value } }));
  };
  const handleMissingPersonSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!missingPersonDraft.name.trim() || !missingPersonDraft.lastSeen.trim() || !missingPersonDraft.contact.trim()) return;
    const report: MissingPersonReport = {
      id: typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}`,
      ...missingPersonDraft,
      name: missingPersonDraft.name.trim(),
      lastSeen: missingPersonDraft.lastSeen.trim(),
      contact: missingPersonDraft.contact.trim(),
      notes: missingPersonDraft.notes.trim(),
      location: location.name,
      reportedAt: new Date().toISOString(),
    };
    setMissingPeople((reports) => {
      const next = [report, ...reports];
      window.localStorage.setItem("resq-pulse-missing-people", JSON.stringify(next));
      return next;
    });
    setMissingPersonDraft({ name: "", age: "", lastSeen: "", contact: "", notes: "" });
  };
  const removeMissingPerson = (id: string) => {
    setMissingPeople((reports) => {
      const next = reports.filter((report) => report.id !== id);
      window.localStorage.setItem("resq-pulse-missing-people", JSON.stringify(next));
      return next;
    });
  };
  const saveCapacityProfile = () => {
    const nextProfile = Object.fromEntries(resourceSeed.map((resource) => {
      const draft = capacityDraft[resource.name] || { stock: String(resource.stock), baseNeed: String(resource.baseNeed) };
      return [resource.name, { stock: Math.max(0, Number(draft.stock) || 0), baseNeed: Math.max(0, Number(draft.baseNeed) || 0) }];
    })) as CapacityProfile;
    const nextProfiles = { ...capacityProfiles, [location.name]: nextProfile };
    setCapacityProfiles(nextProfiles);
    window.localStorage.setItem("resq-pulse-capacity-profiles", JSON.stringify(nextProfiles));
    setIsEditingCapacity(false);
  };

  const loadWeather = async (nextLocation: LocationResult) => {
    setIsLoading(true);
    setError("");
    setDispatchPlan(null);
    try {
      const params = new URLSearchParams({
        latitude: String(nextLocation.latitude),
        longitude: String(nextLocation.longitude),
        current: "temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,wind_speed_10m,uv_index,weather_code",
        daily: "weather_code,temperature_2m_max,uv_index_max,precipitation_sum,precipitation_probability_max,wind_speed_10m_max",
        forecast_days: "14",
        timezone: "auto",
      });
      const response = await fetch(`https://api.open-meteo.com/v1/forecast?${params.toString()}`);
      if (!response.ok) throw new Error("Telemetry endpoint returned an error");
      const data = (await response.json()) as WeatherResponse;
      setWeather(data);
      setLocation(nextLocation);
      setLastSynced(new Date());
    } catch (fetchError) {
      setError(fetchError instanceof Error ? fetchError.message : "Unable to reach Open-Meteo telemetry");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    void loadWeather(QUICK_CITIES[0]);
  }, []);

  useEffect(() => {
    let cancelled = false;
    const loadTrafficFlow = async () => {
      setTrafficLoading(true);
      setTrafficError("");
      try {
        const response = await fetch(`/api/traffic-flow?latitude=${encodeURIComponent(location.latitude)}&longitude=${encodeURIComponent(location.longitude)}`);
        const data = (await response.json()) as TrafficFlowResponse & { error?: string };
        if (!response.ok) throw new Error(data.error || "TomTom traffic flow unavailable");
        if (!cancelled) setTrafficFlow(data);
      } catch (trafficFetchError) {
        if (!cancelled) {
          setTrafficFlow(null);
          setTrafficError(trafficFetchError instanceof Error ? trafficFetchError.message : "TomTom traffic flow unavailable");
        }
      } finally {
        if (!cancelled) setTrafficLoading(false);
      }
    };
    void loadTrafficFlow();
    return () => { cancelled = true; };
  }, [location.latitude, location.longitude]);

  const current = weather?.current;
  const threat = current ? getThreat(current.precipitation, current.wind_speed_10m) : "stable";
  const threatInfo = threatMeta[threat];

  const forecast = useMemo(() => {
    if (!weather) return [];
    return weather.daily.time.map((date, index) => {
      const rain = weather.daily.precipitation_sum[index] || 0;
      const wind = weather.daily.wind_speed_10m_max[index] || 0;
      const risk: Threat = rain > 25 || wind > 35 ? "severe" : rain > 8 || wind > 20 ? "watch" : "stable";
      return {
        date,
        rain,
        wind,
        temp: weather.daily.temperature_2m_max[index] || 0,
        uv: weather.daily.uv_index_max[index] || 0,
        probability: weather.daily.precipitation_probability_max[index] || 0,
        code: weather.daily.weather_code[index] || 0,
        risk,
      };
    });
  }, [weather]);

  const firstHighRisk = forecast.find((day) => day.risk === "severe");
  const forecastPeakRain = forecast.reduce((peak, day) => Math.max(peak, day.rain), 0);
  const forecastPeakWind = forecast.reduce((peak, day) => Math.max(peak, day.wind), 0);
  const forecastPeakUv = forecast.reduce((peak, day) => Math.max(peak, day.uv), 0);
  const forecastPeakTemp = forecast.reduce((peak, day) => Math.max(peak, day.temp), 0);
  const forecastWatchDays = forecast.filter((day) => day.risk !== "stable").length;
  const locationLoad = current ? clamp(1 + (current.precipitation * 0.035) + (current.wind_speed_10m * 0.006) + (forecastWatchDays * 0.012), 1, 1.55) : 1;
  const needMultiplier = clamp(locationLoad * (threat === "severe" ? 1.14 : threat === "watch" ? 1.05 : 1), 1, 1.75);
  const resources = useMemo(
    () => resourceSeed.map((resource) => {
      const configured = activeCapacity[resource.name] || { stock: resource.stock, baseNeed: resource.baseNeed };
      const need = Math.ceil(configured.baseNeed * needMultiplier);
      return { ...resource, stock: configured.stock, baseNeed: configured.baseNeed, need, deficit: configured.stock - need };
    }),
    [activeCapacity, needMultiplier],
  );
  const totalDeficit = resources.reduce((sum, resource) => sum + Math.max(0, -resource.deficit), 0);
  const topDeficit = resources.reduce((top, resource) => resource.deficit < top.deficit ? resource : top, resources[0]);
  const engineConfidence = weather ? clamp(96 - (forecastWatchDays * 1.5) - (current?.precipitation || 0) * 0.4, 72, 96) : 0;
  const deploymentByResource: Record<string, { deployed: number; location: string; eta: string; status: "deployed" | "warehouse" | "en-route" }> = {
    "Medical trauma kits": { deployed: 50, location: "Relief Camp A · Flood Zone", eta: "4h · emergency procurement", status: "deployed" },
    "Potable drinking water": { deployed: 1800, location: "Relief Camp A + Ward 12", eta: "6h · Bangalore depot", status: "en-route" },
    "Rescue boats / convoys": { deployed: 4, location: "East River staging point", eta: "2h · ready reserve", status: "deployed" },
    "Temporary emergency shelters": { deployed: 72, location: "Municipal warehouse 03", eta: "8h · transfer window", status: "warehouse" },
  };
  const resourceConfidence = (resourceName: string) => resourceName === "Potable drinking water" ? Math.round(engineConfidence - 8) : Math.round(engineConfidence - 3);
  const alertCategories: Array<"All" | AlertCategory> = ["All", "Weather", "Road", "Fire", "Flood", "Air Quality", "Civic"];
  const visibleAlerts = SMART_ALERTS.filter((alert) => !dismissedAlerts.includes(alert.id) && (alertFilter === "All" || alert.category === alertFilter));
  const alertCount = (category: "All" | AlertCategory) => SMART_ALERTS.filter((alert) => !dismissedAlerts.includes(alert.id) && (category === "All" || alert.category === category)).length;
  const handleAlertAction = (alert: SmartAlert, action: string) => {
    if (action === "Dismiss") setDismissedAlerts((items) => [...items, alert.id]);
    else if (action === "Pin to decisions") setPinnedAlert(alert.id);
    else if (action === "View affected components" || action === "Update relief plan") jumpTo("resources", "resource-engine");
    else if (action === "Track incident") jumpTo("traffic", "traffic-density");
    else setAlertActionMessage(`${action} queued for ${alert.type.toLowerCase()}.`);
  };

  const traffic = useMemo(() => {
    const profile = TRAFFIC_BASELINE_BY_CITY[location.name] || { total: 9000, bikeShare: 0.4, carShare: 0.48, heavyShare: 0.12, jamAt: 14000 };
    const flow = trafficFlow?.flowSegmentData;
    const currentSpeed = flow?.currentSpeed || 0;
    const freeFlowSpeed = flow?.freeFlowSpeed || 0;
    const ratio = freeFlowSpeed > 0 ? currentSpeed / freeFlowSpeed : 1;
    const level = flow?.roadClosure ? "CLOSED" : ratio < 0.35 ? "JAMMED" : ratio < 0.65 ? "HEAVY" : "MOVING";
    const congestionScore = Math.round(clamp((1 - ratio) * 100, 0, 100));
    const delayPercent = flow?.freeFlowTravelTime && flow.currentTravelTime ? Math.max(0, Math.round(((flow.currentTravelTime / flow.freeFlowTravelTime) - 1) * 100)) : 0;
    const localHour = weather?.timezone ? Number(new Intl.DateTimeFormat("en-US", { hour: "numeric", hour12: false, timeZone: weather.timezone }).format(new Date())) : new Date().getHours();
    const rushFactor = [7, 8, 9, 17, 18, 19].includes(localHour) ? 1.32 : [10, 11, 12, 13, 14, 15, 16].includes(localHour) ? 0.94 : 0.66;
    const weatherFactor = (current?.precipitation || 0) > 3 ? 0.9 : 1;
    const liveFlowFactor = trafficFlow ? clamp(1 + ((1 - ratio) * 0.65), 0.75, 1.65) : 1;
    const predictedTotal = trafficFlow ? Math.round(profile.total * rushFactor * weatherFactor * liveFlowFactor) : 0;
    return {
      currentSpeed,
      freeFlowSpeed,
      ratio,
      level,
      congestionScore,
      delayPercent,
      confidence: flow?.confidence || 0,
      travelTime: flow?.currentTravelTime || 0,
      freeFlowTravelTime: flow?.freeFlowTravelTime || 0,
      predictedTotal,
      predictionLow: Math.round(predictedTotal * 0.78),
      predictionHigh: Math.round(predictedTotal * 1.22),
      predictedBike: Math.round(predictedTotal * profile.bikeShare),
      predictedCar: Math.round(predictedTotal * profile.carShare),
      predictedHeavy: Math.round(predictedTotal * profile.heavyShare),
      localHour,
      predictionConfidence: trafficFlow ? Math.round(clamp(64 + ((flow?.confidence || 0) * 24), 64, 88)) : 0,
      hasData: Boolean(flow),
    };
  }, [trafficFlow, location.name, weather?.timezone, current]);
  const assistantContext = `Location: ${location.name}, ${location.country || ""}. Weather: ${current ? `${current.temperature_2m}°C, ${current.precipitation}mm precipitation, ${current.wind_speed_10m}km/h wind, UV ${current.uv_index}` : "loading"}. Threat: ${threatInfo.label}. Traffic: ${traffic.hasData ? `${traffic.level}, ${traffic.currentSpeed} km/h, ${traffic.congestionScore}/100 congestion, ${traffic.predictedTotal} predicted vehicles` : "loading"}. Resource open deficit: ${compactNumber(totalDeficit)} units/L. Active Smart Alert Hub alerts: ${alertCount("All")}. Sources: Open-Meteo, Nominatim, OpenStreetMap, TomTom, IMD, NDMA SACHET, CWC, CPCB, NHAI, state transport/police, TrackChild.`;
  const assistantSystem = `You are ResQ-Pulse AI, the helpful operational guide for the ResQ-Pulse disaster resource allocation and commuter safety dashboard. Answer clearly and briefly in plain language. You know the website's features and data sources. Never claim a live value unless it appears in the supplied context. Explain that weather and forecasts come from Open-Meteo; city search comes from Nominatim; maps use OpenStreetMap; live traffic flow and traffic tiles come from TomTom; alert-source labels include IMD, NDMA SACHET, CWC, CPCB, NHAI, state transport/police, and TrackChild. Be transparent that predicted vehicle counts are estimates based on city baseline, local time, weather, and TomTom congestion, not camera counts. Do not invent official alerts, emergency instructions, contacts, or source data. For urgent real-world emergencies, direct the user to local emergency services and official authorities. Current dashboard context:\n${assistantContext}`;
  const getLocalAssistantAnswer = (question: string) => {
    const normalized = question.toLowerCase();
    const liveLocation = `${location.name}${location.country ? `, ${location.country}` : ""}`;
    if (/(feature|what can|how can|help|website|dashboard|modules?)/.test(normalized)) {
      return `ResQ-Pulse brings the operating picture together in one place: live weather and 14-day threat forecasts; weather-aware bike, car, and heavy-fleet safety advice; TomTom traffic status, predicted vehicle volumes, and the colored map; editable city-specific relief capacity planning; AI decision recommendations and dispatch optimization; Smart Alert Hub filtering and actions; duplicate-city search; local timezone display; and the missing-person message box below the traffic map. Pulse can also explain the data sources and current dashboard context.`;
    }
    if (/(source|where.*data|data.*from|api|provider|weather data|forecast)/.test(normalized)) {
      return `The dashboard uses Open-Meteo for current weather and forecasts, Nominatim for city search and place selection, OpenStreetMap for the base map, and TomTom for live traffic flow and traffic tiles. Alert-source labels include IMD, NDMA SACHET, CWC, CPCB, NHAI, state transport or police authorities, and TrackChild. Predicted vehicle counts are estimates from the selected city's baseline, local time, weather, and TomTom congestion—not camera counts.`;
    }
    if (/(missing|lost|person|report)/.test(normalized)) {
      return `Use the “Missing people messages” box directly below the traffic map. Enter the person's name, last-seen place, and a responder contact; age and identifying notes are optional. Select “Add report” to display it immediately. Reports are currently saved in this browser and can be removed with the Remove button.`;
    }
    if (/(traffic|vehicle|bike|car|heavy|jam|congestion|map)/.test(normalized)) {
      return `The traffic panel combines TomTom flow with a city-specific prediction model. It shows movement status, congestion, delay, predicted total vehicles split into two-wheelers, cars, and heavy vehicles, plus green/orange/red traffic tiles on the map. Current operating location: ${liveLocation}.`;
    }
    if (/(resource|capacity|water|shelter|allocation|dispatch|stock|warehouse)/.test(normalized)) {
      return `The Live relief capacity planner recalculates from weather risk and the selected city's editable stock and baseline-need profile. Use “Edit ${location.name} capacity” to change assumptions, then save the profile. The decision engine shows shortages, warehouse stock, deployment location, ETA, confidence, alternatives, and a first-wave dispatch optimization.`;
    }
    if (/(alert|threat|warning|forecast|risk|safety|fleet|rider|heat|uv|rain)/.test(normalized)) {
      return `The Fleet Safety Advisor changes by vehicle type and live weather: bikes react to rain, projected rain, wind, heat, and UV; cars react to traction, visibility, storms, and heat; heavy logistics reacts to waterlogging, crosswinds, heat, and cargo risk. Smart Alert Hub groups operational alerts by weather, road, fire, flood, air quality, and civic categories.`;
    }
    if (/(city|location|search|duplicate|timezone|place)/.test(normalized)) {
      return `Search uses Nominatim and keeps multiple matching places visible so you can choose the correct city. After selection, weather, timezone, traffic, map position, fleet guidance, traffic baseline, and capacity profile recalculate for that location.`;
    }
    if (/(current|now|live|where|temperature|condition)/.test(normalized)) {
      return `The active operating picture is ${liveLocation}. ${current ? `Current weather is ${Math.round(current.temperature_2m)}°C with ${current.precipitation.toFixed(1)}mm precipitation, ${Math.round(current.wind_speed_10m)} km/h wind, and UV ${current.uv_index.toFixed(1)}.` : "Weather telemetry is still loading."} ${traffic.hasData ? `Traffic is ${traffic.level.toLowerCase()} with ${traffic.congestionScore}/100 congestion.` : "Traffic telemetry is still syncing."}`;
    }
    return null;
  };
  const askAssistant = async (event?: FormEvent) => {
    event?.preventDefault();
    const question = assistantInput.trim();
    if (!question || assistantLoading) return;
    setAssistantInput("");
    setAssistantMessages((messages) => [...messages, { role: "user", text: question }]);
    setAssistantLoading(true);
    try {
      const localAnswer = getLocalAssistantAnswer(question);
      if (localAnswer) {
        setAssistantMessages((messages) => [...messages, { role: "assistant", text: localAnswer }]);
        return;
      }
      let result: { answer?: string; error?: string } | null = null;
      try {
        const response = await fetch("/api/assistant", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ question, context: assistantContext }) });
        if (response.ok) result = await response.json() as { answer?: string; error?: string };
      } catch { /* Static deployments do not expose the server route. */ }
      if (!result?.answer) {
        const forgeBaseUrl = String(import.meta.env.VITE_FRONTEND_FORGE_API_URL || "https://forge.manus.ai").replace(/\/+$/, "");
        const forgeKey = import.meta.env.VITE_FRONTEND_FORGE_API_KEY;
        if (!forgeKey) throw new Error("Frontend AI configuration is missing");
        const response = await fetch(`${forgeBaseUrl}/v1/chat/completions`, { method: "POST", headers: { Authorization: `Bearer ${forgeKey}`, "Content-Type": "application/json" }, body: JSON.stringify({ model: "gpt-5-mini", messages: [{ role: "system", content: assistantSystem }, { role: "user", content: question }], max_completion_tokens: 500 }) });
        const payload = await response.json() as { choices?: Array<{ message?: { content?: string | Array<{ text?: string }> } }>; error?: { message?: string } };
        if (!response.ok) throw new Error(payload.error?.message || "AI assistant request failed");
        const content = payload.choices?.[0]?.message?.content;
        const answer = typeof content === "string" ? content : Array.isArray(content) ? content.map((part) => part.text || "").join("") : "I could not generate an answer right now.";
        result = { answer };
      }
      setAssistantMessages((messages) => [...messages, { role: "assistant", text: result?.answer || "I could not generate an answer right now." }]);
    } catch {
      setAssistantMessages((messages) => [...messages, { role: "assistant", text: getLocalAssistantAnswer(question) || "I can answer questions about ResQ-Pulse features, data sources, weather, fleet safety, traffic, relief capacity, alerts, city search, and missing-person reports. Try asking what features this website has or where its traffic data comes from." }]);
    } finally { setAssistantLoading(false); }
  };
  const recommendationItems = [
    { title: `Pre-position ${Math.min(400, Math.max(120, Math.round((resources.find((item) => item.name === "Potable drinking water")?.need || 400) * 0.08)))} L drinking water at Relief Camp A`, rationale: `Flood exposure is ${threat === "severe" ? "high" : "elevated"} and the current live inventory gap is ${compactNumber(Math.max(0, -(resources.find((item) => item.name === "Potable drinking water")?.deficit || 0)))} L.`, timeline: "Complete within 6h", impact: "Protects first-wave coverage for approximately 8,000 people." },
    { title: "Keep the primary response corridor under active watch", rationale: traffic.hasData ? `TomTom flow is ${Math.round(traffic.currentSpeed)} km/h at ${traffic.congestionScore}/100 congestion.` : "Traffic telemetry is still syncing; retain the corridor as the default route.", timeline: "Review at next telemetry refresh", impact: `${traffic.delayPercent}% modeled delay if conditions deteriorate.` },
    { title: `Activate contingency shelter network (${Math.min(12, Math.max(4, forecastWatchDays + 4))} of 12 ready)`, rationale: `${forecastWatchDays}-day watch window and current need projection require a flexible shelter reserve.`, timeline: "Stage before the first high-risk window", impact: "Capacity plan protects displaced residents while keeping reserve stock visible." },
  ];

  const hazard = useMemo(() => {
    const rain = current?.precipitation || 0;
    const wind = current?.wind_speed_10m || 0;
    const temp = current?.temperature_2m || 0;
    const apparent = current?.apparent_temperature || temp;
    const uv = current?.uv_index || 0;
    const peakRain = forecastPeakRain;
    const peakWind = forecastPeakWind;
    const nearTermRain = forecast.slice(0, 3).reduce((sum, day) => sum + day.rain, 0);
    const nearTermPeakTemp = forecast.slice(0, 3).reduce((peak, day) => Math.max(peak, day.temp), 0);
    const heatRisk = apparent >= 38 || temp >= 38 || uv >= 8 || nearTermPeakTemp >= 40;
    const stormRisk = [45, 48, 95, 96, 99].includes(current?.weather_code || 0);
    if (fleetMode === "bike" && (rain > 1 || nearTermRain > 8 || wind > 25 || peakWind > 35)) {
      return { level: "HIGH ALERT", title: "High skid & crosswind hazard", body: `Slip risk active: ${rain.toFixed(1)}mm live rain, ${nearTermRain.toFixed(1)}mm projected in 72h, wind ${Math.round(wind)}km/h. Reduce speed and extend braking distance.`, tone: "red", icon: Bike };
    }
    if (fleetMode === "bike" && heatRisk) {
      return { level: "WATCH", title: "Rider heat-stress risk", body: `Heat exposure elevated: feels-like ${Math.round(apparent)}°C, UV ${uv.toFixed(1)}, forecast peak ${Math.round(forecastPeakTemp)}°C. Schedule shade and hydration breaks.`, tone: "amber", icon: Bike };
    }
    if (fleetMode === "fleet" && (rain > 5 || nearTermRain > 20 || peakRain > 25)) {
      return { level: "HIGH ALERT", title: "Low-lying road waterlogging", body: `Waterlogging risk active: ${nearTermRain.toFixed(1)}mm projected in 72h, peak ${peakRain.toFixed(1)}mm. Reroute heavy logistics from flood-prone corridors.`, tone: "red", icon: Truck };
    }
    if (fleetMode === "fleet" && (peakWind > 45 || wind > 40)) {
      return { level: "WATCH", title: "Heavy-vehicle crosswind risk", body: `Crosswind exposure elevated: live ${Math.round(wind)}km/h, forecast peak ${Math.round(peakWind)}km/h. Restrict exposed bridges and high-sided loads.`, tone: "amber", icon: Truck };
    }
    if (fleetMode === "fleet" && heatRisk) {
      return { level: "WATCH", title: "Fleet heat and cargo stress", body: `Heat load elevated: feels-like ${Math.round(apparent)}°C and UV ${uv.toFixed(1)}. Check driver hydration and temperature-sensitive cargo.`, tone: "amber", icon: Truck };
    }
    if (fleetMode === "car" && (rain > 5 || nearTermRain > 12 || stormRisk || peakWind > 35)) {
      return { level: "WATCH", title: "Reduced visibility & traction", body: `Commuter watch: ${nearTermRain.toFixed(1)}mm projected in 72h${stormRisk ? " with active storm/fog signal" : ""}. Use headlights, slower speeds, and increased following distance.`, tone: "amber", icon: CarFront };
    }
    if (fleetMode === "car" && heatRisk) {
      return { level: "WATCH", title: "Cabin heat-stress risk", body: `Heat exposure elevated: feels-like ${Math.round(apparent)}°C, UV ${uv.toFixed(1)}. Avoid prolonged stopped travel and keep occupants hydrated.`, tone: "amber", icon: CarFront };
    }
    return { level: "CLEAR", title: "Road conditions optimal for transit", body: `No active ${fleetMode === "fleet" ? "logistics" : fleetMode === "bike" ? "rider" : "commuter"} advisory in the live + 72h window.`, tone: "cyan", icon: Check };
  }, [current, fleetMode, forecast, forecastPeakRain, forecastPeakWind, forecastPeakTemp]);

  const handleSearch = async (event: FormEvent) => {
    event.preventDefault();
    const query = search.trim();
    if (!query) return;
    setIsSearching(true);
    setError("");
    try {
      const response = await fetch(`/api/geocode?q=${encodeURIComponent(query)}`);
      if (!response.ok) throw new Error("Geocoding service unavailable");
      const data = (await response.json()) as Array<{ place_id?: number; display_name?: string; name?: string; lat: string; lon: string; address?: { country?: string; country_code?: string; state?: string; county?: string; region?: string } }>;
      const results: LocationResult[] = data.map((result) => ({
        id: result.place_id,
        name: result.name || result.display_name?.split(",")[0] || query,
        display_name: result.display_name,
        country: result.address?.country,
        country_code: result.address?.country_code?.toUpperCase(),
        admin1: result.address?.state || result.address?.county || result.address?.region,
        latitude: Number(result.lat),
        longitude: Number(result.lon),
      })).filter((result) => Number.isFinite(result.latitude) && Number.isFinite(result.longitude));
      setSearchResults(results);
      if (!results.length) {
        setError(`No city found for “${query}”`);
      }
    } catch (searchError) {
      setError(searchError instanceof Error ? searchError.message : "Search failed");
    } finally {
      setIsSearching(false);
    }
  };

  const handleDispatch = async () => {
    if (!weather || isOptimizing || !topDeficit || topDeficit.deficit >= 0) return;
    setIsOptimizing(true);
    await new Promise((resolve) => window.setTimeout(resolve, 650));
    const route = (current?.precipitation || 0) > 5 || (current?.wind_speed_10m || 0) > 35 ? "Unflooded secondary route" : "Primary response corridor";
    setDispatchPlan({
      route,
      eta: threat === "severe" ? 28 : threat === "watch" ? 34 : 40,
      leadResource: topDeficit.name,
      quantity: Math.max(0, -topDeficit.deficit),
      createdAt: new Date(),
    });
    setIsOptimizing(false);
  };
  const handleRefresh = async () => {
    setIsRefreshing(true);
    await loadWeather(location);
    setIsRefreshing(false);
  };
  const acceptRecommendation = (index: number) => setAcceptedRecommendations((items) => items.includes(index) ? items : [...items, index]);
  const deferRecommendation = (index: number) => setDeferredRecommendations((items) => items.includes(index) ? items : [...items, index]);

  return (
    <main className="app-shell">
      <aside className="side-rail">
        <div className="brand-mark" aria-label="ResQ-Pulse">
          <div className="brand-symbol"><Siren size={20} /></div>
          <div>
            <div className="brand-name">ResQ<span>-Pulse</span></div>
            <div className="brand-caption">Crisis operations OS</div>
          </div>
        </div>
        <nav className="rail-nav" aria-label="Primary navigation">
          <div className="rail-section-label">Command center</div>
          <button className={`rail-item ${activeSection === "command" ? "active" : ""}`} onClick={() => jumpTo("command", "command-overview")}><Activity size={16} /> <span>Live command</span><span className="rail-ping" /></button>
          <button className={`rail-item ${activeSection === "fleet" ? "active" : ""}`} onClick={() => jumpTo("fleet", "fleet-safety")}><Route size={16} /> <span>Fleet routing</span></button>
          <button className={`rail-item ${activeSection === "resources" ? "active" : ""}`} onClick={() => jumpTo("resources", "resource-engine")}><Boxes size={16} /> <span>Resource pools</span></button>
          <button className={`rail-item ${activeSection === "threats" ? "active" : ""}`} onClick={() => jumpTo("threats", "threat-forecast")}><ShieldAlert size={16} /> <span>Threat register</span></button>
          <div className="rail-section-label rail-section-spacer">System</div>
          <button className="rail-item" onClick={() => jumpTo("telemetry", "telemetry-panel")}><Radio size={16} /> <span>Telemetry streams</span></button>
          <button className="rail-item" onClick={() => jumpTo("zones", "location-control")}><Crosshair size={16} /> <span>Operating zones</span></button>
        </nav>
        <div className="rail-footer">
          <div className="ops-control-wrap">
            <button className="operator-card" onClick={() => setOpsMenuOpen((open) => !open)} aria-expanded={opsMenuOpen}><div className="operator-avatar">OC</div><div><div className="operator-name">Ops control</div><div className="operator-status"><span /> authenticated</div></div><ChevronRight size={14} className={opsMenuOpen ? "ops-chevron open" : "ops-chevron"} /></button>
            {opsMenuOpen && <div className="ops-menu"><strong>OPS CONTROL</strong><button onClick={() => setDispatchLogOpen(true)}><Radio size={13} /> Live Dispatch Log <small>Recent actions and status</small></button><button onClick={() => setOpsMenuOpen(false)}><Boxes size={13} /> Settings <small>Dashboard preferences</small></button><button onClick={() => setOpsMenuOpen(false)}><ShieldAlert size={13} /> Manual Override <small>Review before changing plans</small></button><button onClick={() => setOpsMenuOpen(false)}><ArrowUpRight size={13} /> Export Report <small>Prepare current operating picture</small></button></div>}
          </div>
          <div className="rail-build">BUILD 04.17.26 <span>•</span> NODE 07</div>
        </div>
      </aside>

      <section className="workspace">
        <header className="topbar">
          <div className="breadcrumb"><span>RESQ-PULSE</span><ChevronRight size={13} /><strong>LIVE COMMAND</strong></div>
          <div className="topbar-right">
            <div className="freshness-widget"><span className="telemetry-status"><span className="status-dot" /> {isRefreshing || isLoading ? "Refreshing telemetry" : "Telemetry active"}</span><span>Last updated {formatTime(lastSynced.toISOString(), weather?.timezone)} · Auto-refresh 30s</span><span className="source-bar"><i /><i /><i /><i /><i /><i /><i /> 7/7 sources</span></div>
            <button className="pause-updates" onClick={() => setUpdatesPaused((paused) => !paused)}>{updatesPaused ? "Resume updates" : "Pause updates"}</button><button className="icon-button" aria-label="Refresh telemetry" onClick={() => void handleRefresh()}><RefreshCw size={15} className={isLoading || isRefreshing ? "spin" : ""} /></button>
          </div>
        </header>

        <div className="content-wrap">
          <section className="hero-row">
            <div>
              <div className="eyebrow"><span className="eyebrow-line" /> Mission-critical operations</div>
              <h1>Disaster resource allocation<br /><em>& commuter safety engine</em></h1>
              <p className="hero-subtitle">One operating picture for moving people, supplies, and decisions before the road closes.</p>
            </div>
            <div className="hero-latency"><span className="latency-label">Signal latency</span><strong>1.2<span>sec</span></strong><span className="latency-up"><ArrowDownRight size={13} /> nominal</span></div>
          </section>

          <section className="location-control panel" id="location-control">
            <div className="location-heading"><div className="location-icon"><Globe2 size={18} /></div><div><span className="panel-kicker">Operating picture</span><strong>{location.name}{location.country ? `, ${location.country}` : ""}</strong></div></div>
            <form className="city-search" onSubmit={handleSearch}>
              <Search size={16} />
              <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search any city worldwide" aria-label="Search any city worldwide" />
              {search && <button type="button" className="clear-search" onClick={() => { setSearch(""); setSearchResults([]); }} aria-label="Clear search"><X size={14} /></button>}
              <button className="search-submit" type="submit" disabled={isSearching}>{isSearching ? <RefreshCw size={14} className="spin" /> : "Locate"}</button>
            </form>
            <div className="quick-cities">{QUICK_CITIES.map((city) => <button key={city.name} className={location.name === city.name ? "quick-city selected" : "quick-city"} onClick={() => void loadWeather(city)}>{city.name}</button>)}</div>
          </section>

          {error && <div className="error-banner"><CircleAlert size={16} /><span>{error}</span><button onClick={() => setError("")} aria-label="Dismiss error"><X size={14} /></button></div>}
          {searchResults.length > 0 && <div className="search-results"><div className="search-results-title">Select a location</div>{searchResults.map((result) => <button key={`${result.latitude}-${result.longitude}`} onClick={() => { void loadWeather(result); setSearch(""); setSearchResults([]); }}><MapPin size={14} /><span>{result.name}{result.country_code ? ` · ${result.country_code}` : ""}</span><small>{result.display_name || `${[result.admin1, result.country].filter(Boolean).join(", ") || "Location result"} · ${result.latitude.toFixed(2)}, ${result.longitude.toFixed(2)}`}</small></button>)}</div>}

          <section className="telemetry-grid" id="command-overview">
            <div className="telemetry-main panel" id="telemetry-panel">
              <div className="panel-header"><div><span className="panel-kicker">Live meteorological telemetry</span><h2>Current conditions</h2></div><div className={`threat-chip ${threatInfo.color}`}><span /> Threat level: {threatInfo.label}</div></div>
              {isLoading && !weather ? <div className="loading-state"><RefreshCw className="spin" size={22} /><span>Locking onto live telemetry…</span></div> : <>
                <div className="current-overview">
                  <div className="temperature-block"><span className="weather-orb"><CloudRain size={26} /></span><div><strong>{Math.round(current?.temperature_2m || 0)}°</strong><span>{weatherCodeLabel(current?.weather_code || 0)}</span></div></div>
                  <div className="current-place"><MapPin size={14} /> {location.name}<span>·</span>{formatTimezoneLabel(weather?.timezone || location.timezone)}</div>
                  <div className="sync-line"><span className="live-pulse" /> Updated {current ? formatTime(current.time, weather?.timezone) : "—"}</div>
                </div>
                <div className="metric-grid">
                  <div className="metric"><div className="metric-icon rain"><CloudRain size={16} /></div><span>Surface rainfall</span><strong>{(current?.precipitation || 0).toFixed(1)} <small>mm</small></strong><div className="metric-note">live precipitation</div></div>
                  <div className="metric"><div className="metric-icon wind"><Wind size={16} /></div><span>Sustained wind</span><strong>{Math.round(current?.wind_speed_10m || 0)} <small>km/h</small></strong><div className="metric-note">10m above surface</div></div>
                  <div className="metric"><div className="metric-icon temp"><Thermometer size={16} /></div><span>Ambient temperature</span><strong>{Math.round(current?.temperature_2m || 0)} <small>°C</small></strong><div className="metric-note">feels-like not modelled</div></div>
                  <div className="metric"><div className="metric-icon humidity"><Droplets size={16} /></div><span>Relative humidity</span><strong>{Math.round(current?.relative_humidity_2m || 0)} <small>%</small></strong><div className="metric-note">near-surface air</div></div>
                </div>
              </>}
            </div>

            <div className={`safety-card panel tone-${hazard.tone}`} id="fleet-safety">
              <div className="panel-header safety-header"><div><span className="panel-kicker">Fleet safety advisory</span><h2>Transit posture</h2></div><div className="advisory-live"><span /> LIVE</div></div>
              <div className="fleet-tabs" role="tablist" aria-label="Fleet type">
                <button role="tab" aria-selected={fleetMode === "bike"} className={fleetMode === "bike" ? "fleet-tab active" : "fleet-tab"} onClick={() => setFleetMode("bike")}><Bike size={15} /><span>Two-wheeler</span></button>
                <button role="tab" aria-selected={fleetMode === "car"} className={fleetMode === "car" ? "fleet-tab active" : "fleet-tab"} onClick={() => setFleetMode("car")}><CarFront size={15} /><span>Commuter car</span></button>
                <button role="tab" aria-selected={fleetMode === "fleet"} className={fleetMode === "fleet" ? "fleet-tab active" : "fleet-tab"} onClick={() => setFleetMode("fleet")}><Truck size={15} /><span>Heavy logistics</span></button>
              </div>
              <div className="hazard-content"><div className="hazard-icon"><hazard.icon size={24} /></div><div><div className="hazard-level">{hazard.level}</div><h3>{hazard.title}</h3><p>{hazard.body}</p></div></div>
              <div className="hazard-footer"><span><Gauge size={14} /> Live {Math.round(current?.apparent_temperature || current?.temperature_2m || 0)}°C feels-like · UV {(current?.uv_index || 0).toFixed(1)}</span><span>Current + 72h model</span></div>
            </div>
          </section>

          <section className="forecast-section panel" id="threat-forecast">
            <div className="panel-header forecast-header"><div><span className="panel-kicker">Predictive disaster threat forecast</span><h2>14-day horizon</h2></div><div className="forecast-legend"><span className="legend-item"><i className="legend-dot red" /> Storm / inundation</span><span className="legend-item"><i className="legend-dot amber" /> Moderate watch</span><span className="legend-item"><i className="legend-dot cyan" /> Stable baseline</span></div></div>
            <div className="forecast-scroll">
              {forecast.map((day, index) => <div className={`forecast-day ${day.risk}`} key={day.date}><div className="forecast-date"><span>{index === 0 ? "TODAY" : formatDate(day.date, { weekday: "short" }).toUpperCase()}</span><strong>{formatDate(day.date, { month: "short", day: "numeric" })}</strong></div><div className="forecast-icon">{day.risk === "severe" ? <AlertTriangle size={17} /> : day.risk === "watch" ? <CloudRain size={17} /> : <Waves size={17} />}</div><div className="forecast-stats"><span><CloudRain size={12} />{day.rain.toFixed(1)}mm</span><span><Wind size={12} />{Math.round(day.wind)}km/h</span></div><div className="forecast-temp">{Math.round(day.temp)}° <small>{day.probability}% rain</small></div><div className="risk-label">{day.risk === "severe" ? "HIGH" : day.risk === "watch" ? "WATCH" : "STABLE"}</div></div>)}
              {!forecast.length && <div className="loading-state"><RefreshCw className="spin" size={18} /> Loading forecast window…</div>}
            </div>
            <div className="staging-card"><div className="staging-symbol"><Navigation size={18} /></div><div><span className="panel-kicker">Pre-disaster staging alert</span>{firstHighRisk ? <p><strong>Pre-emptive staging action:</strong> Move relief supplies 48 hours prior to expected road cut-offs on <b>{formatDate(firstHighRisk.date)}</b>.</p> : <p><strong>No high-hazard window projected.</strong> Maintain distributed inventory posture and monitor daily refreshes.</p>}</div><div className="staging-actions"><button className="mini-primary" onClick={() => setStagingAction("accepted")}>Accept</button><button className="mini-secondary" onClick={() => setStagingAction("deferred")}>Defer 6h</button><button className="mini-secondary" onClick={() => setShowDeferralImpact(true)}>See deferral impact</button><span className="staging-source">Confidence {Math.round(engineConfidence)}%</span></div></div>
            {stagingAction && <div className="action-confirmation"><Check size={14} /> Staging recommendation {stagingAction === "accepted" ? "accepted — relocation workflow queued with a 4h planning ETA." : "deferred by 6h — risk model will recalculate on the next refresh."}<button onClick={() => setStagingAction(null)}><X size={13} /></button></div>}
            {showDeferralImpact && <div className="impact-panel"><strong>Impact of deferral</strong><span>If deferred, modeled supply shortfall risk increases from 12% to 47% during the next high-risk window.</span><button onClick={() => setShowDeferralImpact(false)} aria-label="Close deferral impact"><X size={13} /></button></div>}
          </section>

          <section className="recommendations-section panel" id="decision-recommender">
            <div className="panel-header"><div><span className="panel-kicker">Recommended actions · AI-powered</span><h2>Decision recommender</h2></div><span className="recommendation-source">Forecast + traffic + inventory + response times</span></div>
            <div className="recommendation-list">{recommendationItems.map((item, index) => { const accepted = acceptedRecommendations.includes(index); const deferred = deferredRecommendations.includes(index); return <div className={`recommendation-row ${accepted ? "accepted" : deferred ? "deferred" : ""}`} key={item.title}><div className="recommendation-check"><Check size={15} /></div><button className="recommendation-main" onClick={() => setExpandedRecommendation(expandedRecommendation === index ? null : index)}><strong>{index + 1}. {item.title}</strong><span>{item.rationale}</span>{expandedRecommendation === index && <small>{item.timeline} · {item.impact}</small>}</button><div className="recommendation-actions"><button className="mini-primary" onClick={() => acceptRecommendation(index)} disabled={accepted}>Accept</button><button className="mini-secondary" onClick={() => deferRecommendation(index)} disabled={deferred}>Defer 6h</button><button className="mini-secondary" onClick={() => setExpandedRecommendation(index)}>Custom</button></div></div>; })}</div>
          </section>

          <section className="smart-alert-hub panel" id="smart-alert-hub">
            <div className="panel-header alert-hub-header"><div><span className="panel-kicker">Active alert feed</span><h2>Smart Alert Hub</h2><p>Monitoring: 4 supplier districts · 3 inbound routes · 1 plant</p></div><div className="alert-sync"><span className="live-pulse" /> Last sync: just now<br /><small>Refresh rate: every 30s</small></div></div>
            <div className="alert-filters" role="tablist" aria-label="Alert categories">{alertCategories.map((category) => <button key={category} className={alertFilter === category ? "alert-filter active" : "alert-filter"} onClick={() => setAlertFilter(category)}>{category}<b>{alertCount(category)}</b></button>)}</div>
            {alertActionMessage && <div className="alert-action-message"><Check size={14} /> {alertActionMessage}<button onClick={() => setAlertActionMessage("")}><X size={13} /></button></div>}
            {pinnedAlert && <div className="alert-pin-message"><Pin size={14} /> Pinned alert is now linked to the resource decision flow. <button onClick={() => { setPinnedAlert(null); setAlertActionMessage("Alert unpinned from decisions."); }} aria-label="Unpin alert"><X size={13} /></button></div>}
            <div className="alert-feed">{visibleAlerts.map((alert) => <article className={`smart-alert-card severity-${alert.severity.toLowerCase()} ${pinnedAlert === alert.id ? "pinned" : ""}`} key={alert.id}><div className="alert-card-top"><span className="alert-emoji" aria-hidden="true">{alert.icon}</span><span className={`alert-severity ${alert.severity.toLowerCase()}`}>{alert.severity} ALERT</span><strong>{alert.type} · {alert.location}</strong><time>{alert.time}</time></div><button className="alert-headline" onClick={() => setExpandedAlert(expandedAlert === alert.id ? null : alert.id)}><b>{alert.headline}</b><span>{alert.detail}</span></button><div className="alert-authority">Issuer: {alert.issuer} {alert.verified && <span className="verified">Verified ✓</span>}</div>{(expandedAlert === alert.id || pinnedAlert === alert.id) && <div className="alert-impact-grid"><div><strong>▸ SUPPLY CHAIN IMPACT</strong><span>{alert.supply}</span><button onClick={() => handleAlertAction(alert, "View affected components")}>View affected components</button></div><div><strong>▸ RELIEF / COMMUTER IMPACT</strong><span>{alert.relief}</span><button onClick={() => handleAlertAction(alert, alert.category === "Road" ? "Track incident" : "Update relief plan")}>View impact details</button></div></div>}<div className="alert-actions">{alert.actions.map((action) => <button key={action} className={action === "Dismiss" ? "alert-action secondary" : "alert-action primary"} onClick={() => handleAlertAction(alert, action)}>{action}</button>)}</div></article>)}{!visibleAlerts.length && <div className="alert-empty">No active alerts in this category.</div>}</div>
            <div className="alert-sources">Data sources: NDMA SACHET · IMD · CWC · CPCB · NHAI · State transport/police · TrackChild <span>· Last sync: just now · Refresh rate: every 30 seconds</span></div>
          </section>

          <section className="allocation-section panel" id="resource-engine">
            <div className="panel-header allocation-header"><div><span className="panel-kicker">AI-powered emergency resource allocation engine</span><h2>Live relief capacity planner</h2></div><div className="allocation-meta"><span className="ai-badge"><Bot size={14} /> DECISION ENGINE ONLINE</span><span>Confidence: <strong>{Math.round(engineConfidence)}%</strong></span><button className="edit-capacity-button" onClick={openCapacityEditor}><PackageCheck size={13} /> Edit {location.name} capacity</button></div></div>
            {isEditingCapacity && <div className="capacity-editor"><div className="capacity-editor-heading"><div><span className="panel-kicker">Location-specific assumptions</span><strong>Configure {location.name}</strong><p>These values are saved in this browser and used by the live planner for this city.</p></div><div className="capacity-editor-actions"><button className="secondary-action" onClick={() => setIsEditingCapacity(false)}>Cancel</button><button className="save-capacity-button" onClick={saveCapacityProfile}><Check size={14} /> Save capacity profile</button></div></div><div className="capacity-edit-grid">{resourceSeed.map((resource) => <div className="capacity-edit-row" key={resource.name}><span>{resource.short}<small>{resource.unit}</small></span><label>Stock<input type="number" min="0" value={capacityDraft[resource.name]?.stock || ""} onChange={(event) => updateCapacityDraft(resource.name, "stock", event.target.value)} /></label><label>Baseline need<input type="number" min="0" value={capacityDraft[resource.name]?.baseNeed || ""} onChange={(event) => updateCapacityDraft(resource.name, "baseNeed", event.target.value)} /></label></div>)}</div></div>}
            <div className="allocation-callout"><div className="callout-icon"><Zap size={17} /></div><div><strong>{threat === "severe" ? "Surge allocation required — live hazard load is severe" : threat === "watch" ? "Flex allocation staged — live hazard load is elevated" : "Live baseline allocation active"}</strong><span>Calculated for {location.name} from current rain {current?.precipitation.toFixed(1) || "0.0"}mm, wind {Math.round(current?.wind_speed_10m || 0)}km/h, and {forecastWatchDays} watch day{forecastWatchDays === 1 ? "" : "s"} in the 14-day window.</span></div><div className="callout-total"><span>Net open deficit</span><strong>{compactNumber(totalDeficit)} <small>units / L</small></strong></div></div>
            <div className="engine-inputs"><span><CloudRain size={13} /> Peak rain <b>{forecastPeakRain.toFixed(1)}mm</b></span><span><Wind size={13} /> Peak wind <b>{Math.round(forecastPeakWind)}km/h</b></span><span><Gauge size={13} /> Demand multiplier <b>{needMultiplier.toFixed(2)}×</b></span><span><Clock3 size={13} /> Next recalculation <b>on telemetry refresh</b></span></div>
            <div className="resource-table-wrap"><table className="resource-table"><thead><tr><th>Resource class</th><th>Available</th><th>Deployment</th><th>At warehouse</th><th>Projected need</th><th>Delta / priority</th><th>Confidence</th></tr></thead><tbody>{resources.map((resource) => { const Icon = resource.icon; const deployment = deploymentByResource[resource.name]; const warehouse = Math.max(0, resource.stock - deployment.deployed); const priority = resource.deficit < -5000 ? "CRITICAL" : resource.deficit < 0 ? resource.deficit < -200 ? "URGENT" : "HIGH" : "OPTIMAL"; const alternativeOpen = expandedAlternative === resource.name; return <Fragment key={resource.name}><tr><td><div className="resource-name"><span className={`resource-icon ${resource.color}`}><Icon size={15} /></span><span>{resource.name}<small>{resource.unit} · dynamic model</small></span></div></td><td className="number-cell">{compactNumber(resource.stock)}<span>{resource.unit}</span></td><td><span className={`deployment-detail ${deployment.status}`}><b>{compactNumber(deployment.deployed)}</b> {resource.unit}</span><small className="location-detail">{deployment.location}</small></td><td className="number-cell">{compactNumber(warehouse)}<span>{resource.unit}</span></td><td className="number-cell">{compactNumber(resource.need)}<span>{resource.unit}</span></td><td><div className={`delta-cell ${resource.deficit < 0 ? "negative" : "positive"}`}>{resource.deficit < 0 ? <ArrowDownRight size={14} /> : <Check size={14} />}{resource.deficit < 0 ? "-" : "+"}{compactNumber(Math.abs(resource.deficit))}<span>{resource.unit}</span></div><span className={`priority ${priority.toLowerCase()}`}><span />{priority}</span></td><td><span className="confidence-score">{resourceConfidence(resource.name)}% <small>±{compactNumber(Math.round(Math.max(100, Math.abs(resource.deficit) * .18)))} {resource.unit}</small></span></td></tr>{resource.deficit < 0 && <tr className="shortage-row"><td colSpan={7}><div><strong>Shortage severity: {priority === "CRITICAL" ? "CRITICAL" : "HIGH"} — need {Math.max(2, Math.ceil(resource.need / Math.max(1, resource.stock)))}× current stock</strong><span>Mitigation: {deployment.eta}</span><button className="alternative-button" onClick={() => setExpandedAlternative(alternativeOpen ? null : resource.name)}>View alternatives</button>{alternativeOpen && <em>Alternative: reduce coverage to 2 relief camps; saves {compactNumber(Math.round(resource.need * .18))} {resource.unit}, affecting approximately 8,000 people.</em>}</div></td></tr>}</Fragment>; })}</tbody></table></div>
            {dispatchPlan ? <div className="dispatch-banner success"><div className="dispatch-check"><Check size={18} /></div><div><strong>Dispatch plan executed · {dispatchPlan.route}</strong><span>Moving {compactNumber(dispatchPlan.quantity)} {dispatchPlan.leadResource.toLowerCase()} from Regional Depot B · ETA: {dispatchPlan.eta} mins · calculated {formatTime(dispatchPlan.createdAt.toISOString())}.</span></div><button onClick={() => setDispatchPlan(null)} aria-label="Dismiss dispatch confirmation"><X size={14} /></button></div> : <div className="dispatch-action"><div><span className="panel-kicker">Live decision support</span><p>{topDeficit?.deficit < 0 ? `Authorize a first-wave dispatch to cover the largest live gap: ${topDeficit.name}.` : "Current live stock covers the modeled requirement."}</p></div><button className="dispatch-button" onClick={() => void handleDispatch()} disabled={isOptimizing || !weather || !topDeficit || topDeficit.deficit >= 0}><Send size={15} /> {isOptimizing ? "Calculating dispatch route…" : "Execute live dispatch optimization"} <ArrowUpRight size={14} /></button></div>}
          </section>

          <section className="traffic-section panel" id="traffic-density">
            <div className="panel-header traffic-header"><div><span className="panel-kicker">TomTom live traffic flow</span><h2>Traffic state by vehicle class</h2></div><div className={`traffic-status ${traffic.level.toLowerCase()}`}><span /> {trafficLoading ? "SYNCING" : traffic.level}</div></div>
            <div className="traffic-summary"><div className="traffic-summary-icon"><Route size={18} /></div><div><strong>{traffic.hasData ? `${compactNumber(traffic.predictedTotal)} predicted vehicles` : trafficLoading ? "Connecting to TomTom traffic flow…" : "Predicted volume unavailable"}</strong><span>{traffic.hasData ? `Range ${compactNumber(traffic.predictionLow)}–${compactNumber(traffic.predictionHigh)} · ${traffic.congestionScore}/100 congestion · ${traffic.delayPercent}% delay · model confidence ${traffic.predictionConfidence}%` : trafficError || "TomTom Flow API is not returning data for this point."}</span></div><div className="traffic-clock"><span>Local clock</span><b>{formatTime(new Date().toISOString(), weather?.timezone)}</b><small>{formatTimezoneLabel(weather?.timezone || location.timezone)}</small></div></div>
            <div className="traffic-grid">
              <div className="traffic-card bike"><div className="traffic-card-icon"><Bike size={17} /></div><div><span>Two-wheelers</span><strong>{traffic.hasData ? compactNumber(traffic.predictedBike) : "—"}</strong><small>Predicted bikes · live {Math.round(traffic.currentSpeed)} km/h</small></div><b>{traffic.level}</b></div>
              <div className="traffic-card car"><div className="traffic-card-icon"><CarFront size={17} /></div><div><span>Commuter cars</span><strong>{traffic.hasData ? compactNumber(traffic.predictedCar) : "—"}</strong><small>Predicted cars · live {Math.round(traffic.currentSpeed)} km/h</small></div><b>{traffic.level}</b></div>
              <div className="traffic-card heavy"><div className="traffic-card-icon"><Truck size={17} /></div><div><span>Heavy vehicles</span><strong>{traffic.hasData ? compactNumber(traffic.predictedHeavy) : "—"}</strong><small>Predicted logistics · live {Math.round(traffic.currentSpeed)} km/h</small></div><b>{traffic.level}</b></div>
            </div>
            <div className="traffic-map-shell"><TrafficMap latitude={location.latitude} longitude={location.longitude} locationName={location.name} /><div className="traffic-map-badge"><span className="live-pulse" /> TomTom live flow · OpenStreetMap base</div></div>
            <div className="traffic-note"><CircleAlert size={13} /> Predicted volume uses the selected city baseline, local time, weather, and TomTom congestion ratio. It is an operational estimate with a range, not a camera or loop-detector count.</div>
            <section className="missing-person-box" aria-labelledby="missing-person-title">
              <div className="missing-person-heading"><div><span className="panel-kicker">Community response intake</span><h3 id="missing-person-title"><MessageCircle size={17} /> Missing people messages</h3><p>Record a missing-person report for the selected operating area. Reports are saved on this device.</p></div><span className="missing-count">{missingPeople.length} report{missingPeople.length === 1 ? "" : "s"}</span></div>
              <form className="missing-person-form" onSubmit={handleMissingPersonSubmit}>
                <label>Full name<input value={missingPersonDraft.name} onChange={(event) => setMissingPersonDraft((draft) => ({ ...draft, name: event.target.value }))} placeholder="Enter full name" required /></label>
                <label>Age<input type="number" min="0" max="130" value={missingPersonDraft.age} onChange={(event) => setMissingPersonDraft((draft) => ({ ...draft, age: event.target.value }))} placeholder="Optional" /></label>
                <label>Last seen / place<input value={missingPersonDraft.lastSeen} onChange={(event) => setMissingPersonDraft((draft) => ({ ...draft, lastSeen: event.target.value }))} placeholder="Landmark or address" required /></label>
                <label>Contact / phone<input value={missingPersonDraft.contact} onChange={(event) => setMissingPersonDraft((draft) => ({ ...draft, contact: event.target.value }))} placeholder="How responders can reach you" required /></label>
                <label className="missing-notes">Description or notes<textarea value={missingPersonDraft.notes} onChange={(event) => setMissingPersonDraft((draft) => ({ ...draft, notes: event.target.value }))} placeholder="Clothing, identifying details, medical needs…" rows={2} /></label>
                <button className="missing-submit" type="submit"><Send size={14} /> Add report</button>
              </form>
              {missingPeople.length > 0 ? <div className="missing-person-list">{missingPeople.map((report) => <article className="missing-person-card" key={report.id}><div className="missing-person-avatar"><MapPin size={16} /></div><div className="missing-person-details"><strong>{report.name}{report.age ? <small> · {report.age} yrs</small> : null}</strong><span>Last seen: {report.lastSeen} · {report.location}</span><span>Contact: {report.contact}</span>{report.notes && <p>{report.notes}</p>}</div><button className="missing-remove" onClick={() => removeMissingPerson(report.id)} aria-label={`Remove report for ${report.name}`}>Remove</button></article>)}</div> : <div className="missing-empty"><MessageCircle size={16} /> No missing-person reports have been entered for this device.</div>}
            </section>
          </section>

          {dispatchLogOpen && <div className="drawer-backdrop" onClick={() => setDispatchLogOpen(false)}><aside className="dispatch-drawer" onClick={(event) => event.stopPropagation()}><div className="drawer-header"><div><span className="panel-kicker">OPS CONTROL</span><h2>Live dispatch log</h2></div><button className="icon-button" onClick={() => setDispatchLogOpen(false)} aria-label="Close dispatch log"><X size={15} /></button></div><div className="dispatch-log-entry"><span>Now</span><strong>{dispatchPlan ? "Dispatch optimization executed" : "No dispatch executed in this session"}</strong><small>Resource: {dispatchPlan?.leadResource || "Awaiting authorization"} · Location: {location.name} · Status: {dispatchPlan ? "Routed" : "Ready"}</small></div><div className="dispatch-log-entry"><span>{formatTime(lastSynced.toISOString(), weather?.timezone)}</span><strong>Telemetry refresh</strong><small>Weather, traffic flow, and forecast synchronized for {location.name}.</small></div></aside></div>}

          <div className={`assistant-shell ${assistantOpen ? "open" : ""}`}>
            {assistantGreeting && !assistantOpen && <button className="assistant-greeting" onClick={() => { setAssistantOpen(true); setAssistantGreeting(false); }}>Hi — I’m Pulse. Ask me anything about this dashboard <span>×</span></button>}
            {assistantOpen && <section className="assistant-panel" aria-label="ResQ-Pulse AI assistant"><div className="assistant-header"><div><span className="assistant-status"><span /> AI ASSISTANT</span><strong>Pulse</strong><small>Knows the dashboard + its sources</small></div><button onClick={() => setAssistantOpen(false)} aria-label="Close AI assistant"><X size={15} /></button></div><div className="assistant-messages">{assistantMessages.map((message, index) => <div className={`assistant-message ${message.role}`} key={`${message.role}-${index}`}><span>{message.text}</span></div>)}{assistantLoading && <div className="assistant-message assistant"><span className="assistant-typing">Thinking…</span></div>}</div><form className="assistant-form" onSubmit={askAssistant}><input value={assistantInput} onChange={(event) => setAssistantInput(event.target.value)} placeholder="Ask about weather, traffic, sources…" aria-label="Ask Pulse a question" /><button type="submit" disabled={assistantLoading || !assistantInput.trim()} aria-label="Send question"><Send size={15} /></button></form><div className="assistant-source-note">Source-aware answers · live context: {location.name}</div></section>}
            {!assistantOpen && <button className="assistant-launcher" onClick={() => { setAssistantOpen(true); setAssistantGreeting(false); }} aria-label="Open Pulse AI assistant"><MessageCircle size={21} /><span>Pulse AI</span><i /></button>}
          </div>

          <footer className="workspace-footer"><span><span className="footer-pulse" /> Open-Meteo Telemetry: Active (14-Day Window)</span><span>All calculations client-side · last refresh {formatTime(lastSynced.toISOString())}</span><span>RESQ-PULSE / OPS NODE 07</span></footer>
        </div>
      </section>
    </main>
  );
}
