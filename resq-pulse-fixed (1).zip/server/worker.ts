import "dotenv/config";
import { defaultTaskHandler, startTaskWorker } from "./rabbitmq";

console.log("[RabbitMQ worker] starting; queue=task_queue");

startTaskWorker(defaultTaskHandler).catch((error) => {
  console.error("[RabbitMQ worker] fatal error", error);
  process.exitCode = 1;
});
