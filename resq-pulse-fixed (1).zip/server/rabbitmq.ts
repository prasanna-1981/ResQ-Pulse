import amqp, { type Channel, type ChannelModel, type ConfirmChannel, type ConsumeMessage } from "amqplib";

export const TASK_QUEUE = "task_queue";
export const FAILED_TASK_QUEUE = "task_queue_failed";

export type TaskMessage = {
  id: string;
  type: string;
  payload: Record<string, unknown>;
  createdAt: string;
  attempts: number;
};

type NewTask = Pick<TaskMessage, "type" | "payload"> & Partial<Pick<TaskMessage, "id" | "createdAt" | "attempts">>;

type TaskHandler = (task: TaskMessage) => Promise<void>;

let producerChannelPromise: Promise<ConfirmChannel> | null = null;
let activeWorkerConnection: ChannelModel | null = null;

function getRabbitUrl() {
  const url = process.env.RABBITMQ_URL;
  if (!url) throw new Error("RABBITMQ_URL is not configured");
  return url;
}

function resetProducerChannel() {
  producerChannelPromise = null;
}

async function getProducerChannel(): Promise<ConfirmChannel> {
  if (producerChannelPromise) return producerChannelPromise;

  producerChannelPromise = amqp.connect(getRabbitUrl()).then(async (connection) => {
    connection.on("error", (error) => console.error("[RabbitMQ producer] connection error", error));
    connection.once("close", resetProducerChannel);
    const channel = await connection.createConfirmChannel();
    channel.on("error", (error) => console.error("[RabbitMQ producer] channel error", error));
    channel.once("close", resetProducerChannel);
    await channel.assertQueue(TASK_QUEUE, { durable: true });
    await channel.assertQueue(FAILED_TASK_QUEUE, { durable: true });
    return channel;
  }).catch((error) => {
    resetProducerChannel();
    throw error;
  });

  return producerChannelPromise;
}

export async function publishTask(input: NewTask) {
  const task: TaskMessage = {
    id: input.id || crypto.randomUUID(),
    type: input.type,
    payload: input.payload || {},
    createdAt: input.createdAt || new Date().toISOString(),
    attempts: input.attempts || 0,
  };
  const channel = await getProducerChannel();
  const accepted = channel.sendToQueue(TASK_QUEUE, Buffer.from(JSON.stringify(task)), {
    persistent: true,
    contentType: "application/json",
    messageId: task.id,
    type: task.type,
  });
  if (!accepted) throw new Error("RabbitMQ write buffer is full; retry the task submission");
  await channel.waitForConfirms();
  return task;
}

function parseTask(message: ConsumeMessage): TaskMessage {
  const parsed = JSON.parse(message.content.toString()) as Partial<TaskMessage>;
  if (typeof parsed.id !== "string" || typeof parsed.type !== "string" || typeof parsed.payload !== "object" || parsed.payload === null) {
    throw new Error("Invalid task message: expected id, type, and payload");
  }
  return {
    id: parsed.id,
    type: parsed.type,
    payload: parsed.payload as Record<string, unknown>,
    createdAt: typeof parsed.createdAt === "string" ? parsed.createdAt : new Date().toISOString(),
    attempts: typeof parsed.attempts === "number" ? parsed.attempts : 0,
  };
}

export const defaultTaskHandler: TaskHandler = async (task) => {
  // Replace this switch with application-specific work. Keeping it async makes
  // the worker safe for API calls, database writes, and other I/O-bound tasks.
  console.log(`[RabbitMQ worker] processed ${task.type} (${task.id})`, task.payload);
};

function wait(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function consumeUntilDisconnected(handler: TaskHandler) {
  const connection = await amqp.connect(getRabbitUrl());
  activeWorkerConnection = connection;
  console.log(`[RabbitMQ worker] connected; queue=${TASK_QUEUE}`);
  connection.on("error", (error) => console.error("[RabbitMQ worker] connection error", error));
  const channel = await connection.createChannel();
  channel.on("error", (error) => console.error("[RabbitMQ worker] channel error", error));
  await channel.assertQueue(TASK_QUEUE, { durable: true });
  await channel.assertQueue(FAILED_TASK_QUEUE, { durable: true });
  await channel.prefetch(1);

  let closed = false;
  const disconnected = new Promise<void>((resolve) => {
    connection.once("close", () => {
      closed = true;
      resolve();
    });
  });

  await channel.consume(TASK_QUEUE, async (message) => {
    if (!message || closed) return;
    try {
      const task = parseTask(message);
      await handler(task);
      channel.ack(message);
      console.log(`[RabbitMQ worker] acknowledged ${task.id}`);
    } catch (error) {
      const description = error instanceof Error ? error.message : String(error);
      console.error("[RabbitMQ worker] task failed; moving to task_queue_failed", description);
      channel.sendToQueue(FAILED_TASK_QUEUE, message.content, { persistent: true, contentType: message.properties.contentType || "application/json" });
      channel.nack(message, false, false);
    }
  }, { noAck: false });

  await disconnected;
  try { await channel.close(); } catch { /* connection already closed */ }
  if (activeWorkerConnection === connection) activeWorkerConnection = null;
}

export async function startTaskWorker(handler: TaskHandler = defaultTaskHandler) {
  let stopping = false;
  const stop = () => {
    stopping = true;
    void activeWorkerConnection?.close();
  };
  process.once("SIGINT", stop);
  process.once("SIGTERM", stop);

  let delay = 1000;
  while (!stopping) {
    try {
      await consumeUntilDisconnected(handler);
      delay = 1000;
    } catch (error) {
      console.error(`[RabbitMQ worker] disconnected; retrying in ${delay}ms`, error instanceof Error ? error.message : error);
      if (!stopping) await wait(delay);
      delay = Math.min(delay * 2, 30_000);
    }
  }
  process.removeListener("SIGINT", stop);
  process.removeListener("SIGTERM", stop);
}

export type { TaskHandler };
