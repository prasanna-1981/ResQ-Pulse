import { describe, expect, it } from "vitest";
import amqp from "amqplib";

describe("CloudAMQP RabbitMQ credentials", () => {
  it("connects, declares task_queue, and closes cleanly", async () => {
    const url = process.env.RABBITMQ_URL;
    expect(url, "RABBITMQ_URL must be configured").toBeTruthy();

    const connection = await amqp.connect(url!);
    const channel = await connection.createChannel();
    await channel.assertQueue("task_queue", { durable: true });
    await channel.close();
    await connection.close();
  }, 20_000);
});
