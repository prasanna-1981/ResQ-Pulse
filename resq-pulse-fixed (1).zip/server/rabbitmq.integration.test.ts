import amqp from "amqplib";
import { describe, expect, it } from "vitest";
import { publishTask, TASK_QUEUE } from "./rabbitmq";

describe("RabbitMQ task producer", () => {
  it("publishes a durable task to task_queue", async () => {
    const task = await publishTask({ type: "integration_test", payload: { ok: true } });
    const connection = await amqp.connect(process.env.RABBITMQ_URL!);
    const channel = await connection.createChannel();
    await channel.assertQueue(TASK_QUEUE, { durable: true });
    const message = await channel.get(TASK_QUEUE, { noAck: false });
    expect(message).not.toBe(false);
    if (message) {
      const received = JSON.parse(message.content.toString()) as { id?: string; type?: string; payload?: { ok?: boolean } };
      expect(received.id).toBe(task.id);
      expect(received.type).toBe("integration_test");
      expect(received.payload?.ok).toBe(true);
      channel.ack(message);
    }
    await channel.close();
    await connection.close();
  }, 20_000);
});
