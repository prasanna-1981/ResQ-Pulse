import express from "express";
import { createServer } from "http";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const server = createServer(app);
  app.use(express.json({ limit: "64kb" }));

  app.post("/api/assistant", async (req, res) => {
    const question = typeof req.body?.question === "string" ? req.body.question.trim() : "";
    const context = typeof req.body?.context === "string" ? req.body.context.slice(0, 6000) : "";
    if (!question) return res.status(400).json({ error: "A question is required" });
    const forgeBaseUrl = (process.env.BUILT_IN_FORGE_API_URL || "").replace(/\/+$/, "");
    const forgeKey = process.env.BUILT_IN_FORGE_API_KEY;
    if (!forgeBaseUrl || !forgeKey) return res.status(503).json({ error: "AI assistant is not configured" });
    const system = `You are ResQ-Pulse AI, the helpful operational guide for the ResQ-Pulse disaster resource allocation and commuter safety dashboard. Answer clearly and briefly in plain language. You know the website's features and data sources. Never claim a live value unless it appears in the supplied context. Explain that weather and forecasts come from Open-Meteo; city search comes from Nominatim; maps use OpenStreetMap; live traffic flow and traffic tiles come from TomTom; alert-source labels include IMD, NDMA SACHET, CWC, CPCB, NHAI, state transport/police, and TrackChild. Be transparent that predicted vehicle counts are estimates based on city baseline, local time, weather, and TomTom congestion, not camera counts. Do not invent official alerts, emergency instructions, contacts, or source data. For urgent real-world emergencies, direct the user to local emergency services and official authorities. Current dashboard context:\n${context}`;
    try {
      const response = await fetch(`${forgeBaseUrl}/v1/chat/completions`, {
        method: "POST",
        headers: { Authorization: `Bearer ${forgeKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({ model: "gpt-5-mini", messages: [{ role: "system", content: system }, { role: "user", content: question }], max_completion_tokens: 500 }),
      });
      const body = await response.json() as { choices?: Array<{ message?: { content?: string | Array<{ text?: string }> } }>; error?: { message?: string } };
      if (!response.ok) return res.status(502).json({ error: body.error?.message || "AI assistant request failed" });
      const content = body.choices?.[0]?.message?.content;
      const answer = typeof content === "string" ? content : Array.isArray(content) ? content.map((part) => part.text || "").join("") : "I could not generate an answer right now.";
      return res.json({ answer });
    } catch (error) {
      return res.status(502).json({ error: error instanceof Error ? error.message : "AI assistant request failed" });
    }
  });

  app.get("/api/geocode", async (req, res) => {
    const query = typeof req.query.q === "string" ? req.query.q.trim() : "";
    if (!query) return res.status(400).json({ error: "A search query is required" });
    try {
      const params = new URLSearchParams({ q: query, format: "jsonv2", addressdetails: "1", limit: "7" });
      const response = await fetch(`https://nominatim.openstreetmap.org/search?${params.toString()}`, {
        headers: { "User-Agent": "ResQ-Pulse/1.0 (live emergency operations dashboard)", "Accept-Language": "en" },
      });
      const body = await response.text();
      res.status(response.status).type("application/json").send(body);
    } catch (error) {
      res.status(502).json({ error: error instanceof Error ? error.message : "Nominatim search failed" });
    }
  });

  app.get("/api/traffic-flow", async (req, res) => {
    const latitude = Number(req.query.latitude);
    const longitude = Number(req.query.longitude);
    const apiKey = process.env.TOMTOM_API_KEY;
    if (!apiKey) return res.status(503).json({ error: "TOMTOM_API_KEY is not configured" });
    if (!Number.isFinite(latitude) || !Number.isFinite(longitude) || latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180) {
      return res.status(400).json({ error: "Valid latitude and longitude are required" });
    }

    const params = new URLSearchParams({ point: `${latitude},${longitude}`, unit: "KMPH", key: apiKey });
    try {
      const response = await fetch(`https://api.tomtom.com/traffic/services/4/flowSegmentData/absolute/10/json?${params.toString()}`);
      const body = await response.text();
      res.status(response.status).type("application/json").send(body);
    } catch (error) {
      res.status(502).json({ error: error instanceof Error ? error.message : "TomTom traffic request failed" });
    }
  });

  app.get("/api/tomtom-tile/:z/:x/:y", async (req, res) => {
    const apiKey = process.env.TOMTOM_API_KEY;
    const { z, x, y } = req.params;
    if (!apiKey) return res.status(503).send("TOMTOM_API_KEY is not configured");
    if (![z, x, y].every((value) => /^\d+$/.test(value))) return res.status(400).send("Invalid tile coordinates");

    const tileUrl = `https://api.tomtom.com/traffic/map/4/tile/flow/relative/${z}/${x}/${y}.png?key=${encodeURIComponent(apiKey)}`;
    try {
      const response = await fetch(tileUrl);
      if (!response.ok) return res.status(response.status).send(await response.text());
      res.setHeader("Content-Type", response.headers.get("content-type") || "image/png");
      res.setHeader("Cache-Control", "public, max-age=30");
      res.send(Buffer.from(await response.arrayBuffer()));
    } catch (error) {
      res.status(502).send(error instanceof Error ? error.message : "TomTom traffic tile request failed");
    }
  });

  // Serve static files from dist/public in production
  const staticPath =
    process.env.NODE_ENV === "production"
      ? path.resolve(__dirname, "public")
      : path.resolve(__dirname, "..", "dist", "public");

  app.use(express.static(staticPath));

  // Handle client-side routing - serve index.html for all routes
  app.get("*", (_req, res) => {
    res.sendFile(path.join(staticPath, "index.html"));
  });

  const port = process.env.PORT || 3000;

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
